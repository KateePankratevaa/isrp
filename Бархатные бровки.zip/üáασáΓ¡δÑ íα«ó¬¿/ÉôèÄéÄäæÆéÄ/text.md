# Бархатные бровки

## 1. Структура задания

Задание обычно содержит следующие каталоги и файлы (названия могут немного отличаться):
- `общие ресурсы/Требования и рекомендации.pdf` - общие требования, описывающие процедуру экзамена;
- `общие ресурсы/Введение.pdf` - краткое описание предметной области;
- `общие ресурсы/Руководство по стилю.pdf` - руководство по стилю, содержит требования к дизайну приложения;
- `общие ресурсы/README.md` - шаблон для *README* файла на языке **markdown**;
- `общие ресурсы/logo.png` - логотип программы;
- `общие ресурсы/logo.ico` - иконка программы;
- `сессия 1.pdf` - задание на разработку;
- `сессия 1/*` - файлы, необходимые для выполнения задания (скрипты БД, файлы для импорта и тому подобное).

Внимательно изучите содержимое папок. Ознакомтесь с файлом `сессия 1.pdf`.

## 2. Список задач

Для того, чтобы ничего не забыть, пропишите для себя на листочке или в отдельном файле все задачи/функциональные требования, которые необходимо выполнить. Примерный перечень:
- восстановить базу из скрипта;
- импортировать данные;
- реализовать режим администратора;
-- обычный режим - доступен только список услуг;
-- режим администратора - доступны все функции;
- реализовать окно услуг;
-- реализовать переход на окно услуг;
-- реализовать вывод услуг в соответствии с шаблоном (см. содержимое папок, файл `service_layout.png`);
-- при выводе услуги необходимо выводить: наименование услуги, стоимость, продолжительность, миниатюра главного изображения, размер скидки;
-- выделение скидки (светло-зеленый фон, цена зачеркнута);
-- сортировка услуг по цене;
-- фильтрация услуг по размеру скидки;
-- поиск услуги;
-- реализовать вывод количества данных;
-- реализовать удаление услуги;
- добавление/редактирование услуги;
-- реализовать переход на соответствующее окно;
-- услуга должна содержать следующие данные: название, стоимость, длительность, описание, скидку,
основное изображение;
-- реализовать добавление/изменение;
-- реализовать проверку, существует ли такая услуга в системе (по названию);
-- реализовать ограничение по длительности услуги;
-- реализовать возможность добавления/замены одного основного изображения к услуге;
- реализовать работу с дополнительными изображениями к услуге;
-- вывод изображений;
-- добавление и удаление изображений;
- реализовать запись клиента на услугу;
- реализовать вывод ближайших услуг.

## 3. Работа с базой данных

### 3.1 Восстановление данных из скрипта

Откройте среду **SSMS** (Sql Server Managment Studio). Выполните подключение (к локальной или удаленной базе, зависит от ситуации).

Создайте базу данных `VelvetEyebrows`.

Откройте файл скрипта с помощью SSMS. Используйте для этого стандартные пользовательские решения, например меню файл->открыть->файл или drag-n-drop ("перетащить" файл из проводника в окно с программой). Небходимый файл для открытия - `ms.sql` (задание может содержать несколько скриптов под различные СУБД).

Изучите текст скрипта. Скрипт не содержит инструкции `USE <DATABASE>`, поэтому будет вызван для текущей активной базы данных. Нам необходимо это исправить. Для этого подойдет один из двух вариантов.

Вариант №1. Выбрать активную базу с помощью всплывающего списка:
![](1.png)

Вариант №2. Добавить в начало скрипта инструкцию:
```sql
USE VelvetEyebrows;
```

После, необходимо нажать на кнопку "Выполнить". Если все успешно, то вы увидите подобное сообщение:
```
Выполнение команд успешно завершено.

Время выполнения: 2022-12-17T12:36:09.0566677+05:00
```

Если возникла ошибка, то проверьте, что:
- в базе уже не созданы таблицы (скрипт выполнился дважды);
- вы задали активную БД;
- был выбран корректный скрипт `ms.sql`.

Не забывайте обновлять элементы с помощью кнопки обновить (чтобы перезагрузить таблицы/иные объекты базы):
![](2.png)

### 3.2 Построение диаграммы

Постройте диаграмму БД. Для этого:
- нажмите ПКМ на разделе *Диаграммы баз данных*;
- выберите пункт *создать диаграмму баз данных*;
- в появившемся окне добавьте на диаграмму все таблицы;

Полученный результат:
![](3.png)

### 3.3 Импорт данных

Изучите файлы для импорта:
- client_b_import;
- service_b_import;
- serviceclient_b_import;

Определите таблицы для вставки. Проанализируйте поля.

#### 3.3.1 Импорт клиентов

Откройте программу Excel. Создайте пустую книгу.

На вкладке данные выберите пункт "Из текстового/CSV файла":
![](4.png)

Выберите файл client_b_import.txt.

Задайте кодировку, соответствующую кодировке файла (UTF-8).
Задайте разделитель столбцов (запятая).
![](5.png)

Выполните вставку на лист книги Excel (кнопка "Загрузить").

Проанализируем проблемы:
- ФИО в некоторых случаях оказалось записанным слитно;
- в строке пол помимо "м" и "ж", встречаются строки "мужской" и "женский".

Также, проанализируем схему:
![](6.png)

Между таблицами `Client` и `Gender` создана связь. Это значит, что нам нужно будет сперва заполнить таблицу `Gender`.

Выполним заполнение таблицы `Gender`:
![](7.png)
![](8.png)

Выполним замену в столбце Excel. Для этого:
- выделим необходимый столбец (Пол);
- вызовем окно "Найти и заменить" (CTRL-F);
- заменим "мужской" на "м" и "женский" на "ж".

![](9.png)


Выполним разбивку ФИО. Сперва нужно отсортировать значения по имени:
![](10.png)

Затем нужно выделить "слитные" данные:
![](11.png)

После чего используем функцию "Текст по столбцам":
![](12.png)

В первом окно выбераем "с разделителями". Во втором окно задаем в качестве разделителя пробел:
![](13.png)

Полученный результат:
![](14.png)

#### 3.3.2 Удаление пробельных символов по краям

Некоторые записи (например, номер телефона), могут иметь лишние пробельные символы в начале и в конце. Чтобы от них избавиться используем следующий прием:
- с краю, где-нибудь в ячейке L2 используем функцию СЖПРОБЕЛЫ, передав в качестве параметра ячейку с номером телефона;
- копируем функцию ("растягиваем" вниз) с помощью встроенных инструментов Excel;
- полученные значения копируем в столбец с номерами телефонов, используя вставку значений;
- при успешной замене данных, столбец L нам больше не нужен, его можно удалить.

Аналогичным образом можно удалить лишние пробелы в других столбцах (если это необходимо). Лишние пробелы могут быть препятствием при импорте данных (если оказалсь, например, в поле с датой).

#### 3.3.3 Выполнение импорта клиентов

Сохраните полученную таблицу в формате csv.
Самостоятельно выполните импорт из подготовленного файла с помощью мастера импорта.

#### 3.3.4 Импорт услуг

Самостоятельно выполните импорт услуг. Для этого:
- в поле стоимость уберите все лишние символы, оставив только числа;
- добейтесь того, чтобы скидка была в долях (пример: 10% - это 0.1; 5% - 0.05; 25% - 0.25). Подумайте, какое значение следует задать, если скидки нет;
- посмотрите, в какой единице измерения задана длительность услуги в базе данных. Выполните преобразование в таблице для импорта с помощью условия (ЕСЛИ), и операций умножения или деления;
- в столбце с изображением удалите название каталога, оставив только имена файлов ("Услуги салона красоты\брови.png" -> "брови.png");
- проверьте наличие лишних пробельных символов;
- выполните импорт с помощью мастера.


#### 3.3.5 Импорт записей на услуги


Исходная таблица (serviceclient_b_import.xls) содержит столбцы с клиентом, услугой и временем. Проблема заключается в том, что для импорта, вместо фамилии клиента и названия услуги нам будут нужны их идентификаторы.

Решим эту проблему с помощью функции ВПР.
https://www.google.com/search?q=%D0%B2%D0%BF%D1%80+excel

Для начала нам нужно подготовить дополнительные таблицы для поиска. В таблицах первым столбцом должен быть тот столбец, по которому происходит поиск. В случае с клиентами таким столбцом будет фамилия, в случае с услугами название. 

Получим таблицу для клиентом. Обратимся к базе данных и выполним запрос (вы же уже импортировали данные?):
```sql
SELECT LastName, ID FROM Client;
```

Полученный результат скопируем в serviceclient_b_import.xls на отдельный лист.
![](15.png)
![](16.png)

Аналогично проделаем для услуг:
```sql
SELECT Title, ID FROM Service;
```
![](17.png)

**Обратите внимание**: идентификаторы в примерах и идентификаторы у вас могут не совпадать. Также, в общем-то они не обязаны начинаться с единицы.

На основном листе применим функцию ВПР:
![](18.png)

Здесь:
- **искомое значение** - значение, которое мы ищем (в данном случае указываем ячейку с фамилией клиента);
- **таблица** - таблица, по которой происходит поиск (используем таблицу с клиентами);
- **номер столбца** - номер столбца из таблицы, из которого нужно взять результат (берем 2 столбец - идентификаторы);
- **интервальный просмотр** - следует установить ЛОЖЬ, если данные в таблице не были отсортированны;

Для значения "таблица" задайте абсолютную адресацию (клавиша F4), чтобы при копировании диапазон не "уезжал вниз".
![](19.png)

Получите значение для одной ячейки (в примере G2, просто нажатие на ОК). Раскопируйте формулу, чтобы получить идентификаторы всех клиентов:
![](20.png)

По аналогии самостоятельно получите услуги:
![](21.png)

Импортируйте значения в базу данных с помощью мастера. Для удобства сохраните правую часть таблицы в отдельный CSV-файл. 

## 4. Работа со списком услуг

### 4.1 Начальные приготовления

Сперва нужно создать проект WPF (.NET 6). В качестве названия проекта следует указать что-нибудь разумное, вроде VelvetEyebrows или BeautySaloon (смотрите файл "требования и рекомендации", в примерах будет использовано название VelvetEyebrows1712).

Для упрощения работы с дизайном, используем библиотеку MaterialDesignThemes. 
![](22.png)

На странице проекта
https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit
вы можете прочитать руководства по использованию.

Изменим файл `app.xaml`:
```xml
<Application
	...
	xmlns:materialDesign="http://materialdesigninxaml.net/winfx/xaml/themes"
    ...>
```

```xml
    <Application.Resources>
        <ResourceDictionary>
            <ResourceDictionary.MergedDictionaries>
                <materialDesign:BundledTheme BaseTheme="Light" PrimaryColor="DeepPurple" SecondaryColor="Lime" />
                <ResourceDictionary Source="pack://application:,,,/MaterialDesignThemes.Wpf;component/Themes/MaterialDesignTheme.Defaults.xaml" />
            </ResourceDictionary.MergedDictionaries>
        </ResourceDictionary>
    </Application.Resources>
```

В целом, библиотека подключена, мы можем использовать стили и новые компоненты.


### 4.2 Окно входа

Реализуем окно входа, где можно будет выбрать один из двух режимов:
- режим киоска (доступны только услуги);
- режим администратора (доступны все функции, требуется пин-код).

Сделаем для окна недоступным изменение размеров. Установим ширину и высоту в 500 пунктов. Установим размер шрифта (FontSize) 22. Шрифт Tahoma (FontFamily).

Изменим код разметки:
```xml
<StackPanel VerticalAlignment="Center">
    <Image Width="200" Height="200" />
    <Label Content="PIN-Код:" Margin="10 0" />
    <PasswordBox Margin="10 0"  />
    <CheckBox Content="Войти в режиме киоска" Margin="10 20" />
    <Button Content="Вход" Margin="10" />
</StackPanel>
```

Вид окна после запуска программы:
![](23.png)

Добавим логотип. Сперва создадим папку `Assets`. В ней создадим папку Images. В ней разместим файл логотипа `logo.png` (см. папки с заданием).
![](24.pNg)

Для файла в окне свойств (ПКМ->свойства или клавиша F4), следует проверить, что он включен в сборку как ресурс:
![](25.png)

Изменим код элемента `Image`:
```xml
<Image Source="./Assets/Images/beauty_logo.png"
       Margin="0 0 0 25" Width="200" Height="200" />
```
Точка в пути означает, что мы используем ресурс.

Примерный вид программы после запуска:
![](26.png)

### 4.3 Цвета

Material Design предлагает собственные наборы цветов (см. страницу проекта). Однако, при необходимости, мы можем задать наши, пользовательские цвета. Для этого нужно просто задать в ресурсах определенные кисти. Страницы с информацией:
https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit/wiki/Brush-Names
https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit/wiki/Custom-Palette-Hues

Изменим код файла app.xaml согласно руководству:
```xml
<Application.Resources>
    <ResourceDictionary>
        <ResourceDictionary.MergedDictionaries>
            <materialDesign:BundledTheme BaseTheme="Light" PrimaryColor="DeepPurple" SecondaryColor="Lime" />
            <ResourceDictionary Source="pack://application:,,,/MaterialDesignThemes.Wpf;component/Themes/MaterialDesignTheme.Defaults.xaml" />
            <ResourceDictionary>
                <!-- primary -->
                <SolidColorBrush x:Key="PrimaryHueLightBrush" Color="#744CE0"/>
                <SolidColorBrush x:Key="PrimaryHueLightForegroundBrush" Color="#FFFFFF"/>
                <SolidColorBrush x:Key="PrimaryHueMidBrush" Color="#6134D9"/>
                <SolidColorBrush x:Key="PrimaryHueMidForegroundBrush" Color="#FFFFFF"/>
                <SolidColorBrush x:Key="PrimaryHueDarkBrush" Color="#4D1DCF"/>
                <SolidColorBrush x:Key="PrimaryHueDarkForegroundBrush" Color="#FFFFFF"/>
                <!-- accent -->
                <SolidColorBrush x:Key="SecondaryHueMidBrush" Color="#5C5B5E"/>
                <SolidColorBrush x:Key="SecondaryHueMidForegroundBrush" Color="#FFFFFF"/>
            </ResourceDictionary>
        </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
</Application.Resources>
```

Далее, зададим цвета из руководства по стилю:
- \#FFFFFF - цвет фона;
- \#E1E4FF - дополнительный цвет;
- \#FF4A6D - акцентирование внимания

```xml
<Application.Resources>
    <ResourceDictionary>
        <ResourceDictionary.MergedDictionaries>
            <materialDesign:BundledTheme BaseTheme="Light" PrimaryColor="DeepPurple" SecondaryColor="Lime" />
            <ResourceDictionary Source="pack://application:,,,/MaterialDesignThemes.Wpf;component/Themes/MaterialDesignTheme.Defaults.xaml" />
            <ResourceDictionary>
                    <SolidColorBrush x:Key="PrimaryHueLightBrush" Color="#FF4A6D"/>
                    <SolidColorBrush x:Key="PrimaryHueLightForegroundBrush" Color="White"/>
                    <SolidColorBrush x:Key="PrimaryHueMidBrush" Color="#FF4A6D"/>
                    <SolidColorBrush x:Key="PrimaryHueMidForegroundBrush" Color="White"/>
                    <SolidColorBrush x:Key="PrimaryHueDarkBrush" Color="#FF4A6D"/>
                    <SolidColorBrush x:Key="PrimaryHueDarkForegroundBrush" Color="White"/>
                
                <SolidColorBrush x:Key="SecondaryHueMidBrush" Color="#E1E4FF"/>
                <SolidColorBrush x:Key="SecondaryHueMidForegroundBrush" Color="Black"/>
            </ResourceDictionary>
        </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
</Application.Resources>
```

Немного изменим стили и свойства элементов окна:
```xml
<StackPanel VerticalAlignment="Center">
    <Image Source="./Assets/Images/beauty_logo.png"
           Margin="0 0 0 25" Width="200" Height="200" />
    <Label Content="PIN-Код:" Margin="10 0" FontWeight="Bold" />
    <PasswordBox Margin="10 0"  />
    <CheckBox Content="Войти в режиме киоска" Margin="10 20"  />
    <Button IsDefault="True" Content="Вход" Height="50" FontSize="22" Margin="10" Cursor="Hand" />
</StackPanel>
```

Свойство `IsDefault` позволяет кнопке срабатывать при нажатии на `Enter`.
Для ввода кода используем `PasswordBox`, чтобы скрывать символы.

Полученный результат:
![](27.png)

### 4.4 Иконка приложения

Загрузим иконку для нашего приложения (см. папки с заданиями).

Для этого следует нажать ПКМ по проекту в обозревателе решений, и выбрать пункт "свойства". Во вкладке свойств следует найти поле для задания иконки и выбрать предоставляемый файл (.ico):
![](28.png)

### 4.5 Создание папки

Для структурирования вашего проекта создайте папку `Views` и перенесите в нее файл с кодом окна входа:
![](29.png)

Переименуем наше окно. Для этого:
- переименуем файлы в LoginWindow;
- переименуем класс в LoginWindow.cs;
- изменим строку с указанием класса в LoginWindow.xaml: `<Window x:Class="VelvetEyebrows1712.LoginWindow" ...`;

![](30.pnG)


В файле app.xaml изменим название стартовой страницы:
```xml
<Application ...
			 ...
             StartupUri="Views/LoginWindow.xaml">
```

После всех махинаций следует проверить, что приложение корректно запускается. Если это так, то вы заметите, что из окна пропал логотип. Это можно исправить, изменив путь (нам теперь нужно вернуться на каталог назад!):
```xml
...
<Image Source="./../Assets/Images/beauty_logo.png"
       Margin="0 0 0 25" Width="200" Height="200" />
...
```

Если после переноса и переименования окна забаговал конструктор, то его просто нужно закрыть и открыть заново.

### 4.6 Создание главного окна

Добавим в папку `Views` новое окно MainWindow.xaml (Добавить -> Окно(WPF)). Зададим ей заголовок "Бархатные броки - главная", размеры 1100х600, шрифт Tahoma.

Разметка окна будет представлять собой сетку:
![](31.png)

В левой части расположим логотип салона и меню, в правой части расположим фрейм, в который будем выводить основное содержимое.

Сперва определим сетку:
```xml
<Grid.ColumnDefinitions>
    <ColumnDefinition Width="200" />
    <ColumnDefinition Width="1*" />
</Grid.ColumnDefinitions>
<Grid.RowDefinitions>
    <RowDefinition Height="200" />
    <RowDefinition Height="1*" />
</Grid.RowDefinitions>
```

Затем добавим логотип:
```xml
<Image Source="./../Assets/Images/beauty_logo.png" Margin="10" />
```

Добавим меню:
```xml
<StackPanel Grid.Row="1" Margin="10">
    <Button Content="Услуги" Margin="0 10" />
    <Button Content="Ближайшие записи" />
</StackPanel>
```

И разместим фрейм:
```xml
<Frame x:Name="mainFrame" Grid.Column="1" Grid.RowSpan="2" />
```

### 4.7 Переход на страницу услуг

Добавим в папку Views страницу ServicesPage (Добавить->Страница(WPF)).

В коде страницы пока что разместим один label:
```xml
<Label Content="Услуги" />
```

Далее, в окне MainWindow добавим обработчик события:
```xml
<Button Content="Услуги" Click="navigateToServices" Margin="0 10" />
```

```cs
private void navigateToServices(object sender, RoutedEventArgs e)
{
    mainFrame.Navigate(new ServicesPage());
}
```

### 4.8 Переход на главное окно

Вернемся в окно входа. Сперва, мы сделаем недоступным поле ввода, если нажата галочка для режима киоска.
Сделаем это с помощью триггера. Зададим имя для CheckBox:
```xml
<CheckBox x:Name="isKioskCheckBox" Content="Войти в режиме киоска" Margin="10 20" />
```
Добавим для PasswordBox стиль, где применим DataTrigger:
```xml
<PasswordBox x:Name="pinCodeInput" Margin="10 0">
    <PasswordBox.Style>
        <Style TargetType="PasswordBox" BasedOn="{StaticResource MaterialDesignPasswordBox}">
            <Style.Triggers>
                <DataTrigger Binding="{Binding ElementName=isKioskCheckBox, Path=IsChecked}" Value="True">
                    <Setter Property="IsEnabled" Value="False" />
                </DataTrigger>
            </Style.Triggers>
        </Style>
    </PasswordBox.Style>
</PasswordBox>
```

`<Style TargetType="PasswordBox" BasedOn="{StaticResource MaterialDesignPasswordBox}">` определяет базовый стиль (`BasedOn`) и тип элемента `PasswordBox`.
`<DataTrigger Binding="{Binding ElementName=isKioskCheckBox, Path=IsChecked}" Value="True">` задает связанное свойство и значение, при котором стиль (сеттеры внутри) будет применен. В данном случае, внутренние сеттеры будут задейстованы, если значение свойства `IsChecked` элемента `isKioskCheckBox` будет равно `True`. 
Единственный `<Setter Property="IsEnabled" Value="False" />` делает поле ввода недоступным.

Следует запустить приложение и проверить, что при получении выбора элементом CheckBox, поле ввода для ПИН-кода становится недоступным.

Напишем обработчик нажатия на кнопку "Вход", создавая окно только в случае входа в режиме киоска или ввода правильного ПИН-кода:
```xml
<Button 
    Click="login"
    Content="Вход" Height="50" 
    FontSize="22" Margin="10" Cursor="Hand" />
```

```cs
private void login(object sender, RoutedEventArgs e)
{
    var wnd = (isKioskCheckBox.IsChecked, pinCodeInput.Password) switch
    {
        (false, "0000") => new MainWindow(), // администратор
        (true, _) => new MainWindow(), // киоск
        _ => null
    };

    if (wnd is null)
    {
        MessageBox.Show("Не верный PIN!", "Вход не выполнен", MessageBoxButton.OK, MessageBoxImage.Warning);
        return;
    }

    wnd.Show();
    Close();
}
```

Теперь, нам нужно чтобы окно создавалось по-разному, в зависимости от режима входа.

Добавим в коде `MainWindow` параметр конструктора и используем его:
```cs
public MainWindow(bool isAdmin)
{
    InitializeComponent();
    if (!isAdmin)
    {
        firstGridColumn.IsEnabled = false;
        firstGridColumn.Width = new GridLength(0);
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        WindowState = WindowState.Maximized;
        mainFrame.Navigate(new ServicesPage());
    }
}
```

Если мы не в режиме админа, то:
- скроем столбец с меню;
- сделаем окно во весь экран без возможности изменения размеров;
- выполним навигацию на страницу услуг.

Чтобы задать имя столбцу, можно использовать обычное свойство `x:Name`:
```xml
<ColumnDefinition x:Name="firstGridColumn" Width="200" />
```

Изменим метод login, задействовав новый конструктор:
```cs
private void login(object sender, RoutedEventArgs e)
{
    var wnd = (isKioskCheckBox.IsChecked, pinCodeInput.Password) switch
    {
        (false, "0000") => new MainWindow(true),
        (true, _) => new MainWindow(false),
        _ => null
    };

    if (wnd is null)
    {
        MessageBox.Show("Не верный PIN!", "Вход не выполнен", MessageBoxButton.OK, MessageBoxImage.Warning);
        return;
    }

    wnd.Show();
    Close();
}
```

### 4.9 Страница услуг

Реализуем вывод услуг в соответствии с макетом.

Корневым компоновочным элементом зададим `DockPanel`. Внутри разместим заголовок:
```xml
<DockPanel>
        <Label DockPanel.Dock="Top" FontSize="35" FontWeight="Bold" Content="Услуги" Margin="0 0 0 25" />
        ...
</DockPanel>
```

После заголовка разместим панель инструментов:
```xml
...
<StackPanel Orientation="Horizontal" 
                    Background="{DynamicResource SecondaryHueMidBrush}" 
            DockPanel.Dock="Top">
    <Label Content="Поиск: " FontSize="18" VerticalAlignment="Center" />
    <TextBox Width="200" 
             Style="{DynamicResource MaterialDesignOutlinedTextBox}" />
    <Label Content="Сортировать по цене: " Margin="10 0 0 0"
            VerticalAlignment="Center" />
    <ComboBox Width="150" Style="{DynamicResource MaterialDesignOutlinedComboBox}" />
    <Label Content="Фильтрация по скидке: " Margin="10 0 0 0"
            VerticalAlignment="Center" />
    <ComboBox Width="150" Style="{DynamicResource MaterialDesignOutlinedComboBox}" />
</StackPanel>
...
```

Внизу страницы будет панель статуса:
```xml
<StatusBar DockPanel.Dock="Bottom" Background="{DynamicResource SecondaryHueMidBrush}" >
    <TextBlock>
        Показано <Run>100</Run> из <Run>250</Run> записей
    </TextBlock>
</StatusBar>
```

Оставшееся пространство займет элемент `ListView`:
```xml
<ListView>
	...
</ListView>
```

Запустите программу, проверьте работоспособность. При необходимости самостоятельно установите адекватные значения свойств для MainWindow (актуально для режима администратора):
- Width, Height;
- MinWidth, MinHeight.

Изменим код конструктора страницы услуг, добавив флаг (включен ли режим администратора):
```cs
public bool IsAdmin { get; private set; }

public ServicesPage(bool isAdmin)
{
    InitializeComponent();
    IsAdmin = isAdmin;
}
```

Самостоятельно исправьте возникшие ошибки в коде. Запустите приложение, проверьте работоспособность.

### 4.10 Scaffold-DbContext

Создадим модель. Для этого вам необходимо установить три пакета:
```
Microsoft.EntityFrameworkCore;
Microsoft.EntityFrameworkCore.SqlServer;
Microsoft.EntityFrameworkCore.Tools;
```

После чего, в консоли диспетчера пакетов NuGet напишем строку:
```
Scaffold-DbContext "Server = (localdb)\MSSQLLocalDB; Database = VelvetEyebrows; Integrated Security = true" Microsoft.EntityFrameworkCore.SqlServer -o Models
```

Команда `Scaffold-DbContext` создает контекст EntityFramework на основании существующей базы данных. 
Первый параметр `"Server = (localdb)\MSSQLLocalDB; Database = VelvetEyebrows; Integrated Security = true"` представляет собой строку подключения,
второй параметр `Micrososft.EntityFrameworkCore.SqlServer` задает провайдера (мы можем использовать различные СУБД, различные пакеты),
далее, ключ `-o` задает выходной каталог.

Выполнив команду, вы получите в папке `Models` набор классов, соответствующих таблицам исходной базы данных.

### 4.11 Глобальная точка

Для простоты, создадим единственную глобальную точку для всего приложения, к которой можно будет обратиться для взаимодействия с экземпляром `DbContext`.
Создадим для этого в папке с проектом следующий класс (используем паттерн "одиночка" - класс с единственным экземпляром):
```cs
public class Session
{
    private Session()
    {
        context = new VelvetEyebrowsContext();
    }

    private static Session? instance;
    public static Session Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new Session();
            }
            return instance;
        }
    }

    private VelvetEyebrowsContext context;
    public VelvetEyebrowsContext Context => context;
}
```

### 4.12 Загрузка услуг

Изменим код страницы услуг, выполнив загрузку значений из базы данных.
```cs
public bool IsAdmin { get; private set; }

public ObservableCollection<Service> Services { get; private set; }

public ServicesPage(bool isAdmin)
{
    IsAdmin = isAdmin;
    Services = new ObservableCollection<Service>(Session.Instance.Context.Services);
    InitializeComponent();
}
```

В коде разметки зададим контекст привязки, указав само окно:
```xml
<Page ...
	  ...
      DataContext="{Binding Mode=OneWay, RelativeSource={RelativeSource Self}}">
```

Зададим источник для списка ListView:
```xml
<ListView ItemsSource="{Binding Services}">
    <ListView.ItemTemplate>
        <DataTemplate>
            ...
        </DataTemplate>
    </ListView.ItemTemplate>
</ListView>
```

Далее, внутри узла `DataTemplate` зададим шаблон одной записи. Чтобы примерный внешний вид было видно в конструкторе, мы добавим свойство `d:ItemsSource`:
```xml
<ListView ItemsSource="{Binding Services}" d:ItemsSource="{d:SampleData ItemCount=5}" >
    <ListView.ItemTemplate>
        <DataTemplate>
           ...
        </DataTemplate>
    </ListView.ItemTemplate>
</ListView>
```

Шаблон создаем исходя из файла `service_layout` (есть в папках с заданием).
Зададим 3 столбца, в первом будет изображение, во втором будет содержание, в третьем кнопки изменения и удаления.

```xml
<Page ...
      ...
      xmlns:materialDesign="http://materialdesigninxaml.net/winfx/xaml/themes"
      ...>
...
	...
        <DataTemplate>
            <Grid Width="800">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="150" />
                    <ColumnDefinition />
                    <ColumnDefinition Width="100" />
                </Grid.ColumnDefinitions>
                <Image Width="150" Height="150" Stretch="Fill" Source="{Binding MainImagePath}" />
                <StackPanel Margin="7" Grid.Column="1">
                    <TextBlock FontSize="22" TextWrapping="Wrap" >
                        <Run FontWeight="SemiBold" Text="{Binding Title}" />
                        <LineBreak />
                        <Run Text="{Binding Cost}" /> 
                        рублей за 
                        <Run Text="{Binding DurationInSeconds}" /> 
                        минут <LineBreak />
                        <TextBlock FontSize="14">
                            * скидка 
                            <Run Text="{Binding Discount}"/> %
                        </TextBlock>
                    </TextBlock>
                    <Button  Margin="20"
                            Content="Записать"/>
                </StackPanel>
                <StackPanel Grid.Column="2" Margin="3"  VerticalAlignment="Top">
                    <Button Margin="0 0 0 2" Style="{DynamicResource MaterialDesignFlatButton}">
                        <materialDesign:PackIcon Kind="Edit" />
                    </Button>
                    <Button Style="{DynamicResource MaterialDesignFlatButton}">
                        <materialDesign:PackIcon Kind="Remove" />
                    </Button>
                </StackPanel>
            </Grid>
        </DataTemplate>
	...
...
```

Далее, зададим панель для ListView:
```xml
<ListView.ItemsPanel>
    <ItemsPanelTemplate>
        <WrapPanel />
    </ItemsPanelTemplate>
</ListView.ItemsPanel>
```

И выключим горизонтальную полосу прокрутки:
```xml
<ListView ...
		  ScrollViewer.HorizontalScrollBarVisibility="Disabled"
          ...
          ... >
...
```

В результате вы получите примерно следующее окно:
![](33.png)

## 4.13 Загрузка изображений

Создадим в папке `Assets/Images` папку `Services`. Поместим в нее изображения услуг.

Через окно свойств зададим изображения копирование в выходной каталог:
![](34.png)

После задания копирования, следует запустить приложение (на F5), и проверить, появились ли в папке с исполняемым файлом изображения. Примерный путь относительно корня проекта: `bin\Debug\net6.0-windows\Assets\Images\Services`.

Для вывода изображений напишем конвертер. Для этого, сперва создадим в корне проекта папку `Converters`. Внутри добавим класс `ImagePathToImageConverter`:
```cs
namespace VelvetEyebrows1712.Converters
{
    internal class ImagePathToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
```

Реализуем метод Convert:
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    if (value is null)
    {
    	// pack://siteoforigin:,,,/ выглядит не очень-то понятно
        
        return "pack://siteoforigin:,,,/Assets/Images/Services/no_image.png";
    }

    var imageName = value.ToString();
    return $"pack://siteoforigin:,,,/Assets/Images/Services/{imageName}";
}
```

Добавим конвертер в app.xaml:
```xml
<converters:ImagePathToImageConverter x:Key="imageConverter" />
```

И в привязку:
```xml
<Image 
    Width="150" Height="150" 
    Stretch="UniformToFill" 
    Source="{Binding MainImagePath, Converter={StaticResource imageConverter}}" />
```

В результате мы получим список услуг с изображениями:
![](35.png)


### 4.14 Работа со скидкой

Изменим шаблон следующим образом:
- если скидки нет, то мы не показываем соответствующую строку;
- если имеется скидка, то мы показываем скидку, цена будет зачеркнутой, цвет фона будет светло-зеленым;

Есть два способа задать внешний вид, зависящий от условий:
- через триггер (`DataTrigger`) - не универсальный, но в некоторых случаях более простой и быстрый в реализации;
- через `IValueConverter` - подходит почти что всегда.

Реализуем вывод скидки с помощью триггера. Сперва определим в `StackPanel` с информацией об услуге (где лежит `TextBlock` и `Button`) стиль:
```xml
<StackPanel.Resources>
    <Style TargetType="TextBlock" x:Key="discountText">
        <Style.Triggers>
            <DataTrigger Binding="{Binding Discount}" Value="0">
                <Setter Property="Visibility" Value="Collapsed" />
            </DataTrigger>
        </Style.Triggers>
    </Style>
</StackPanel.Resources>
```

Далее, определим стиль для соответствующего `TextBlock`:
```xml
<TextBlock FontSize="14" Style="{DynamicResource discountText}">
    * скидка <Run Text="{Binding Discount}" />%
</TextBlock>
```

Готово!

Теперь выведем две цены: цена со скидкой и цена без скидки. Сперва добавим свойство в класс услуги:
```cs
public decimal CostWithDiscount
{
    get
    {
        return Cost * (1 - (decimal)Discount);
    }
}
```

Добавим привязку:
```xml
<TextBlock FontSize="22" TextWrapping="Wrap" >
...
    <Run Text="{Binding Cost}" />
    <Run Text="{Binding CostWithDiscount, Mode=OneWay}" />
    рублей за
    <Run Text="{Binding DurationInSeconds}" />
    минут <LineBreak />
...
</TextBlock>
```

В данный момент, после изменения кода, мы выводим две цены. Скроем вторую, если нет скидки с помощью того же стиля:
```xml
<TextBlock FontSize="22" TextWrapping="Wrap" >
...
    <Run Text="{Binding Cost}" />
    <TextBlock Style="{DynamicResource discountText}" Text="{Binding CostWithDiscount, Mode=OneWay}" />
    рублей за
    <Run Text="{Binding DurationInSeconds}" />
    минут <LineBreak />
...
</TextBlock>
```

Изменим форматирование, убрав лишние нули после запятой:
```xml
<TextBlock FontSize="22" TextWrapping="Wrap" >
...
<Run Text="{Binding Cost, StringFormat={}{0:0.00}}" />
    <TextBlock Style="{DynamicResource discountText}"
               Text="{Binding CostWithDiscount, StringFormat={}{0:0.00}, Mode=OneWay}" />
    рублей за
    <Run Text="{Binding DurationInSeconds}" />
    минут <LineBreak />
...
</TextBlock>
```

Реализуем зачеркнивание при наличии скидки с помощью конвертера. Для этого сперва создадим в папке `Converters` класс `DiscountToStrokeConverter`:
```cs
class DiscountToStrokeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
    	throw new NotImplementedException();
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
```

Код метода `Convert`:
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    var discount = (double)value;
    if (discount > 0)
    {
        return TextDecorations.Strikethrough;
    }
    return null;
}
```

Добавим конвертер в app.xaml:
```xml
<converters:DiscountToStrokeConverter x:Key="discountToStrokeConverter" />
```

И в привязку:
```xml
<Run Text="{Binding Cost, StringFormat={}{0:0.00}}" 
	TextDecorations="{Binding Discount, Converter={StaticResource discountToStrokeConverter}}"/>
```

Примерный результат:
![](36.png)

**Самостоятельно реализуйте корректный вывод времени (в минутах).** Для этого:
- добавьте в класс `Service` новое свойство `DurationInMunites`. Задайте данное свойство только для чтения (описав только геттер);
- выполните привязку свойства `DurationInMunites`;

**Самостоятельно реализуйте выделение записи цветом.** Для этого:
- добавьте конвертер `DiscountToColorConverter`;
- опишите метод `Convert`, вернув *кисть* светло-зеленого или прозрачного цвета. Для светло-зеленой кисти `return Brushes.LightGreen;`;
- добавьте конвертер в app.xaml;
- выполните привязку;

**Самостоятельно реализуйте вывод скидки в целом количестве процентов.**

Примерный результат:
![](37.png)

### 4.15 Отображение кнопок

В режиме киоска кнопки изменения и удаления должны быть недоступны. Реализуем данную функциональность с помощью встроенного конвертера `BooleanToVisibilityConverter`:
- в `StackPanel` с кнопками добавим свойство `Visibility="{Binding ElementName=servicesPage, Path=IsAdmin, Converter={StaticResource BooleanToVisibilityConverter}}"`;
- самой странице зададим имя `x:Name="servicesPage"`;

**Самостоятельно** добейтесь того, чтобы в режиме киоска не было видно кнопку записи.

### 4.16 Поиск и фильтрация

Добавим следующие методы:
```cs
private IQueryable<Service> applySearch(IQueryable<Service> query)
{
    //..
}

private IQueryable<Service> applySort(IQueryable<Service> query)
{
    //..
}

private IQueryable<Service> applyDiscountFilter(IQueryable<Service> query)
{
    //..
}

private void applyFilters()
{
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);

    Services.Clear();
    foreach (Service service in query)
    {
        Services.Add(service);
    }
}
```

Объект `IQuerable` мы можем считать некоторым "подготовленным запросом". Сперва мы применяем фильтр по скидке, затем поиск, затем сортировку. В целом, запрос не будет выполнен до того момента, когда где-либо не понадобятся сами значения. Например, это может быть вызов, вроде `ToList` или использование `foreach`, как в коде выще.

Также, в коде выполняется очистка коллекции и ее заполнение значениями. Поскольку привязанный объект имеет тип `ObservableCollection`, все изменения незамедлительно отобразятся в интерфейсе пользователя.

Реализуем поиск:
```cs
private IQueryable<Service> applySearch(IQueryable<Service> query) =>
    query.Where(q => q.Description.Contains(searchTextBox.Text) || 
        q.Title.Contains(searchTextBox.Text));
```

Здесь, `searchTextBox` - имя для `TextBox`, отвечающего для поиска.

Реализуем сортировку. Жестко закодируем (что не совсем хорошо), значения `ComboBox` по индексам:
```xml
<ComboBox x:Name="sortingComboBox" 
                      Width="150" Style="{DynamicResource MaterialDesignOutlinedComboBox}">
    <ComboBoxItem Content="Не сортировать" />
    <ComboBoxItem Content="По возрастранию" />
    <ComboBoxItem Content="По убыванию" />
</ComboBox>
```

Метод для сортировки:
```cs
private IQueryable<Service> applySort(IQueryable<Service> query) => 
    sortingComboBox.SelectedIndex switch
    {
        1 => query.OrderBy(service => service.Cost),
        2 => query.OrderByDescending(service => service.Cost),
        _ => query
    };
```

`ComboBox` же для фильтрации по цене не будем жестко кодировать. Заполним его значениями с помощью привязки. Сперва добавим в класс страницы публичное свойство:
```cs
public Dictionary<string, Func<IQueryable<Service>, IQueryable<Service>>> DiscountFilters { get; set; } =
    new Dictionary<string, Func<IQueryable<Service>, IQueryable<Service>>>
    {
        { "Все записи", q => q },
        { "0% - 5%", q => q.Where(service => service.Discount >= 0 && service.Discount < 0.05) },
        { "5% - 15%", q => q.Where(service => service.Discount >= 0.05 && service.Discount < 0.15) },
        { "15% - 30%", q => q.Where(service => service.Discount >= 0.15 && service.Discount < 0.30) },
        { "30% - 70%", q => q.Where(service => service.Discount >= 0.3 && service.Discount < 0.7) },
        { "70% - 100%", q => q.Where(service => service.Discount >= 0.7 && service.Discount <= 1) }
    };
```

Затем выполним привязку:
```xml
<ComboBox ItemsSource="{Binding DiscountFilters}" x:Name="filterComboBox"
    Width="150" Style="{DynamicResource MaterialDesignOutlinedComboBox}">
    <ComboBox.ItemTemplate>
        <DataTemplate>
            <Label Content="{Binding Key}" />
        </DataTemplate>
    </ComboBox.ItemTemplate>
</ComboBox>
```

Код метода фильтрации:
```cs
private IQueryable<Service> applyDiscountFilter(IQueryable<Service> query)
{
    if (filterComboBox.SelectedItem == null)
    {
        return query;
    }

    var filterComboBoxItem = (KeyValuePair<string, Func<IQueryable<Service>, IQueryable<Service>>>)filterComboBox.SelectedItem;
    var filterFunc = filterComboBoxItem.Value;
    return filterFunc(query);
}

```

Добавьте обработчики событий на все три элемента (поле ввода и два всплывающих списка):
```cs
private void search(object sender, TextChangedEventArgs e)
{
    applyFilters();
}

private void sort(object sender, SelectionChangedEventArgs e)
{
    applyFilters();
}

private void filter(object sender, SelectionChangedEventArgs e)
{
    applyFilters();
}
```

### 4.17 Вывод количества

Запустите программу и проверьте фильтры. Вы можете увидеть, что программа подвисает в момент выполнения запросов. Уменьшим этот эффект, изменив количество получаемых данных с помощью метода `Take`:
```cs
private void applyFilters()
{
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);

    Services.Clear();
    foreach (Service service in query.Take(25))
    {
        Services.Add(service);
    }
}
```

Теперь мы отдаем за раз не более 25 записей. Подобный подход может быть актуальным в некоторых ситуациях.

Добавим в класс свойства для получения количества записей:
```cs
public int CurrentCount { get; set; }
public int TotalCount { get; set; }
```

Привяжем их к соответствующим элементам:
```xml
<StatusBar DockPanel.Dock="Bottom" Background="{DynamicResource SecondaryHueMidBrush}"  >
    <TextBlock>
        Показано <Run Text="{Binding CurrentCount}" /> из <Run Text="{Binding TotalCount}"/> записей
    </TextBlock>
</StatusBar>
```

Изменим значения:
```cs
private void applyFilters()
{
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);

    Services.Clear();
    foreach (Service service in query.Take(25))
    {
        Services.Add(service);
    }
    CurrentCount = Services.Count;
    TotalCount = Session.Instance.Context.Services.Count();
}
```

Запустите приложение и проверьте работоспособность. Вы увидите, что в оба значения (количество найденных записей и общее количество) равны нулю и не изменяются. Чтобы это исправить, нам необходимо уведомить интерфейс об изменениях. Сперва добавим странице интерфейс:
```cs
public partial class ServicesPage : Page, INotifyPropertyChanged
{
	...
}
```

Затем, реализуем его:
```cs
public event PropertyChangedEventHandler? PropertyChanged;
```

Добавим вспомогательный метод:
```cs
private void notifyPropertyChanged(string propertyName)
{
    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
```

Вызовем метод при изменениях свойств, связанных с количеством:
```cs
private void applyFilters()
{
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);

    Services.Clear();
    foreach (Service service in query.Take(25))
    {
        Services.Add(service);
    }
    CurrentCount = Services.Count;
    notifyPropertyChanged(nameof(CurrentCount));
    TotalCount = Session.Instance.Context.Services.Count();
    notifyPropertyChanged(nameof(TotalCount));
}
```

Запустите программу и проверьте, что при использовании фильтров количество записей изменяется.

**Примечание:**
Обычно, вызов функции, аналогичной `notifyPropertyChanged` производят в сеттере свойств. Примерный код:
```cs
private int currentCount;

public int CurrentCount 
{ 
	get => currentCount; 
	set
    {
    	currentCount = value;
        notifyPropertyChanged("CurrentCount");
    }
}
```
В этом случае не будет необходимости производить дополнительные вызовы в других точках, например, в методе `applyFilters`.

Немного изменим код. Свойство `CurrentCount`:
```cs
private int currentCount;
public int CurrentCount
{
    get => currentCount;
    set
    {
        currentCount = value;
        notifyPropertyChanged("CurrentCount");
    }
}
```

Свойство `TotalCount`:
```cs
private int totalCount;

public int TotalCount
{
    get => totalCount;
    set
    {
        totalCount = value;
        notifyPropertyChanged("TotalCount");
    }
}
```

Код метода `applyFilters`:
```cs
private void applyFilters()
{
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);

    Services.Clear();
    foreach (Service service in query.Take(25))
    {
        Services.Add(service);
    }
    CurrentCount = Services.Count;
    TotalCount = Session.Instance.Context.Services.Count();
}
```

Код конструктора:
```cs
public ServicesPage(bool isAdmin)
{
    IsAdmin = isAdmin;
    Services = new ObservableCollection<Service>(Session.Instance.Context.Services.Take(25));
    CurrentCount = Services.Count;
    TotalCount = Session.Instance.Context.Services.Count();
    InitializeComponent();
}
```

### 4.18 Изменение поиска

Тперь изменим поиск следующим образом:
- при загрузке страницы ничего не выводится;
- записи появляются, когда пользователь вводит строку для поиска;
- если ничего не найдено, то появляется соответствующее сообщение.

Сразу добавим `Label` для вывода сообщения (в XAML перед `ListView`):
```xml
<Label x:Name="searchResultLabel" DockPanel.Dock="Top" Content="Введите поисковый запрос" />
```

Изменим код конструктора, убрав загрузку каких-либо услуг на старте:
```cs
public ServicesPage(bool isAdmin)
{
    IsAdmin = isAdmin;
    Services = new ObservableCollection<Service>();
    CurrentCount = 0;
    TotalCount = Session.Instance.Context.Services.Count();
    InitializeComponent();
}
```

А также код метода `applyFilters`:
```cs
private void applyFilters()
{
	Services.Clear();
    // если ничего не введено, то выводим сообщение "Введите поисковый запрос"
    if (string.IsNullOrWhiteSpace(searchTextBox.Text))
    {
        searchResultLabel.Content = "Введите поисковый запрос";
        searchResultLabel.Visibility = Visibility.Visible;
        CurrentCount = 0;
        return;
    }

    // выполняем поиск подходящих значений
    IQueryable<Service> query = Session.Instance.Context.Services.AsQueryable();
    query = applyDiscountFilter(query);
    query = applySearch(query);
    query = applySort(query);
    
    // заполняем коллекцию значениями
    foreach (Service service in query)
    {
        Services.Add(service);
    }

    CurrentCount = Services.Count;
    
    // выводим сообщение, если ничего не найдено
    if (CurrentCount == 0)
    {
        searchResultLabel.Content = "По данному запросу ничего не найдено";
        searchResultLabel.Visibility = Visibility.Visible;
    }
    else
    {
        searchResultLabel.Visibility = Visibility.Collapsed;
    }

    TotalCount = Session.Instance.Context.Services.Count();
}
```

Проверьте работоспособность. При отсутствии результатов поиска должно быть выведено соответствующее сообщение.

### 4.19 ItemsControl

**Опционально**. Чтобы отказаться от возможности "выделения" элементов ListView при наведении или нажатии, вы можете изменить этот элемент на `ItemsControl`:
```xml
<ItemsControl ScrollViewer.HorizontalScrollBarVisibility="Disabled" 
          ItemsSource="{Binding Services}" 
           >
    <ItemsControl.ItemsPanel>
        <ItemsPanelTemplate>
            <WrapPanel />
        </ItemsPanelTemplate>
    </ItemsControl.ItemsPanel>
    <ItemsControl.ItemTemplate>
        <DataTemplate>
            <Grid Margin="2" Width="800" Background="{Binding Discount, Converter={StaticResource discountToColorConverter}}">
                ...
            </Grid>
        </DataTemplate>
    </ItemsControl.ItemTemplate>
</ItemsControl>
```

### 4.20 Удаление элемента

Добавьте обработчик нажатия на кнопку удаления услуги (`Click`). Код обработчика:
```cs
private void removeService(object sender, RoutedEventArgs e)
{
	var service = (sender as Button)?.DataContext as Service;
    if (service == null) return;

    bool hasClientService = Session.Instance.Context.ClientServices.Any(cs => cs.ServiceId == service.Id);

    if (hasClientService)
    {
        MessageBox.Show("Невозможно удалить услугу, по которой есть записи", "Удаление невозможно",
            MessageBoxButton.OK, MessageBoxImage.Warning);
        return;
    }

    var answer = MessageBox.Show("Вы уверены, что хотите удалить запись", "Подтверждение удаления",
        MessageBoxButton.YesNo, MessageBoxImage.Question);

    if (answer == MessageBoxResult.Yes)
    {
        try
        {
            Session.Instance.Context.Services.Remove(service);
            Session.Instance.Context.SaveChanges();
            MessageBox.Show("Услуга удалена.", "Удаление успешно", 
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch
        {
            MessageBox.Show("Произошла ошибка при удалении!", "Ошибка", 
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
```

Сперва мы получем контекст привязки (экземпляр `Service`). После проверки на `null` определяем, если ли записи с выбранной услугой в таблице `ClientServices`.

В случае, если таких записей нет, запрашиваем у пользователя согласие, и в случае ответа `Yes` выполняем удаление с помощью Entity Framework.

**Самостоятельно** добейтесь автоматического обновления списка (удаленная запись не должна отображаться в интерфейсе окна).

## 5 Добавление и изменение

### 5.1 Окно добавления

Добавим на верхней панели инструментов кнопку:
```xml
<Button Margin="20 0 0 0" Style="{DynamicResource MaterialDesignOutlinedLightButton}" >
    <StackPanel Orientation="Horizontal">
        <materialDesign:PackIcon Height="25" Width="25" Kind="DatabaseAdd" Margin="5 0" />
        <TextBlock Style="{DynamicResource MaterialDesignTextBlock}">Добавить</TextBlock>
    </StackPanel>
</Button>
```

Создадим страницу `UpdateServicePage`. Зададим переход на нее, задав обработчик нажатия кнопки добавления:
```cs
private void goToAddServicePage(object sender, RoutedEventArgs e)
{
    NavigationService.Navigate(new UpdateServicePage(new Service()));
}
```

Изменим код страницы:
```cs
        public Service Service { get; }

        public UpdateServicePage(Service service)
        {
            InitializeComponent();
            Service = service;
            if (Service.Id == 0)
            {
                headerLabel.Content = "Добавление услуги"; // label в верхней части страницы
            }
            else
            {
                headerLabel.Content = "Изменение услуги";
            }
        }
```

Выполним верстку страницы.

Корневым элементом будет `DockPanel`, в верхней части страницы расположим `Label` с заголовком:
```xml
<DockPanel>
    <Label DockPanel.Dock="Top" Content="Добавление услуги" x:Name="headerLabel"
           FontSize="26" FontWeight="Bold" Margin="0 0 0 25" />
```

Далее расположим сетку в 2 столбца и 3 строки:
```xml
<Grid Margin="42">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="250" />
                <ColumnDefinition Width="1*" />
            </Grid.ColumnDefinitions>
            <Grid.RowDefinitions>
                <RowDefinition Height="250" />
                <RowDefinition Height="50" />
                <RowDefinition />
            </Grid.RowDefinitions>
...
```

В первой ячейке будет основное изображение услуги:
```xml
<Image Margin="10" />
```
Ниже расположим кнопку для изменения:
```xml
<Button Grid.Row="1" Margin="5" Content="Изменить" Style="{DynamicResource MaterialDesignFlatAccentBgButton}" HorizontalAlignment="Center" />
```

Еще ниже расположим дополнительные изображения:
```xml
<StackPanel Grid.Row="2">
    <Label Content="Дополнительные изображения" FontSize="14" FontWeight="Medium" HorizontalAlignment="Center" />
    <ItemsControl>
        <ItemsControl.ItemsPanel>
            <ItemsPanelTemplate>
                <WrapPanel ItemHeight="75" ItemWidth="75" />
            </ItemsPanelTemplate>
        </ItemsControl.ItemsPanel>
    </ItemsControl>
    <Button Content="Добавить" HorizontalAlignment="Center" Style="{DynamicResource MaterialDesignFlatAccentBgButton}" />
</StackPanel>
```

В правой части расположим еще одну сетку с полями ввода:
```xml
<Grid Grid.Column="1" Grid.RowSpan="3">
    <Grid.ColumnDefinitions>
        <ColumnDefinition Width="150" />
        <ColumnDefinition Width="1*" />
    </Grid.ColumnDefinitions>
    <Grid.RowDefinitions>
        <RowDefinition Height="50" />
        <RowDefinition Height="50" />
        <RowDefinition Height="50" />
        <RowDefinition Height="50" />
        <RowDefinition Height="120" />
        <RowDefinition Height="1*" />
    </Grid.RowDefinitions>

    <Label Content="Название:" VerticalAlignment="Center" HorizontalAlignment="Left" />
    <TextBox Grid.Column="1" Padding="10" VerticalAlignment="Center"  Style="{DynamicResource MaterialDesignOutlinedTextBox}" />
    <Label Content="Стоимость:" Grid.Row="1" VerticalAlignment="Center" HorizontalAlignment="Left" />
    <TextBox Grid.Column="1" Padding="10" Grid.Row="1" VerticalAlignment="Center" Style="{DynamicResource MaterialDesignOutlinedTextBox}" />
    <Label Content="Длительность:" Grid.Row="2" VerticalAlignment="Center" HorizontalAlignment="Left" />
    <ComboBox Padding="10" Style="{DynamicResource MaterialDesignOutlinedComboBox}"  Grid.Row="2" Grid.Column="1" />
    <Label Content="Скидка:" Grid.Row="3" VerticalAlignment="Center" HorizontalAlignment="Left" />
    <ComboBox Padding="10" Style="{DynamicResource MaterialDesignOutlinedComboBox}" Grid.Row="3" Grid.Column="1" />
    <Label Content="Описание:" Grid.Row="4" VerticalAlignment="Center" HorizontalAlignment="Left" Cursor="" />
    <TextBox Padding="10" Grid.Column="1" Grid.Row="4"
             Style="{DynamicResource MaterialDesignOutlinedTextBox}"  TextWrapping="Wrap" AcceptsReturn="True" />
    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Row="5" Grid.Column="1">
        <Button Content="Сохранить" Width="150"  />
        <Button Content="Назад" Width="150" Margin="5 0" />
    </StackPanel>
</Grid>
```

Примерный вид страницы при загрузке:
![](38.png)

### 5.2 Кнопка Назад

Добавим обработчик на нажатие кнопки назад:
```cs
private void goBack(object sender, RoutedEventArgs e)
{
    NavigationService.GoBack();
}
```

Самой кнопке установим свойство `IsCancel` в `true`, чтобы она работала как действие отмены по умолчанию (например, при нажатии на Escape):
```xml
<Button Content="Назад" IsCancel="True" Click="goBack" Width="150" Margin="5 0" />
```

### 5.3 Длительность услуги

Задайте странице контекст привязки (саму на себя) с помощью XAML или C#. 

Добавьте публичное свойство:
```cs
public List<int> Durations { get; set; } = new();
```

Код конструктора, в котором длительность услуг задана с шагом в 5 минут:
```cs
public UpdateServicePage(Service service)
{
    Service = service;

    for (int i = 15; i <= 420; i += 5)
    {
        Durations.Add(i);
    }

    InitializeComponent();

    if (Service.Id == 0)
    {
        headerLabel.Content = "Добавление услуги";
    }
    else
    {
        headerLabel.Content = "Изменение услуги";
    }
    // контекст через код:
    // DataContext = this;
}
```

Выполним привязку для `ComboBox`:
```xml
<ComboBox Padding="10" Style="{DynamicResource MaterialDesignOutlinedComboBox}" 
                          Grid.Row="2" Grid.Column="1" 
                          ItemsSource="{Binding Durations}">
    <ComboBox.ItemTemplate>
        <DataTemplate>
            <TextBlock>
                <Run Text="{Binding Mode=OneWay}" /> минут
            </TextBlock>
        </DataTemplate>
    </ComboBox.ItemTemplate>
</ComboBox>
```

После запуска программы должны быть отображены все возможные варианты длтельности оказания услуги.

### 5.4 Скидки

Аналогичным образом выполним привязку коллекции со скидками:
```cs
public List<int> Discounts { get; set; } = new();
```
```cs
...
    for (int i = 0; i <= 95; i += 5)
    {
        Discounts.Add(i);
    }
...
```

```xml
<ComboBox Padding="10" 
          ItemsSource="{Binding Discounts}"
          Style="{DynamicResource MaterialDesignOutlinedComboBox}" 
          Grid.Row="3" Grid.Column="1">
    <ComboBox.ItemTemplate>
        <DataTemplate>
            <TextBlock Text="{Binding Mode=OneWay, StringFormat={}{0}%}" />
        </DataTemplate>
    </ComboBox.ItemTemplate>
</ComboBox>
```


### 5.5 Привязка свойств

Выполним привязку всех необходимых свойств. Типичная привязка для `TextBox`:
```xml
...
<TextBox Grid.Column="1" Padding="10" 
     Text="{Binding Service.Title}"
     VerticalAlignment="Center" 
     Style="{DynamicResource MaterialDesignOutlinedTextBox}" />
...
```

Для выпадающих списков с длительностью и скидкой привязка будет сделана несколько сложнее. Рассмотрим привязку длительности. В данный момент `ComboBox` хранит значение в минутах, однако в базе данных значение должно быть в секундах. Чтобы все работало как надо, нам нужно задать преобразование из секунд в минуты и обратно. Для осуществления такого преобразования напишем еще один конвертер:
```cs
public class SecondsToMinutesConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        int seconds = (int)value;
        return seconds / 60;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        int minutes = (int)value;
        return minutes * 60;
    }
}
```

Обратите внимание, что в отличии от предыдущих конвертеров, нам важно задать обратное преобразование `ConvertBack`.

Добавим конвертер в ресурсы:
```xml
<converters:SecondsToMinutesConverter x:Key="timeConverter" />
```

Выполним привязку:
```xml
<ComboBox Padding="10" Style="{DynamicResource MaterialDesignOutlinedComboBox}"
      Grid.Row="2" Grid.Column="1" 
      SelectedItem="{Binding Service.DurationInSeconds, Converter={StaticResource timeConverter}}"
      ItemsSource="{Binding Durations}">
```

Реализуйте аналогичную привязку для выбора скидки **самостоятельно**.

### 5.6 Привязка изображения

Используем разработанный ранее конвертер:
```xml
<Image Margin="10" Source="{Binding Service.MainImagePath, Converter={StaticResource imageConverter}}" /> 
```

Если все было сделано правильно, то при открытии страницы будет показано изображение по умолчанию.

### 5.7 Открытие окна для изменения

Добавим обработчик для кнопки изменения услуги:
```xml
<Button Margin="0 0 0 2" Click="editService"
    Style="{DynamicResource MaterialDesignFlatButton}">
<materialDesign:PackIcon Kind="Edit" />
...
```

```cs
private void editService(object sender, RoutedEventArgs e)
{
    var service = (sender as Button)?.DataContext as Service;
    if (service == null) return;
    NavigationService.Navigate(new UpdateServicePage(service));
}
```

Проверьте работоспособность. При загрузке должны отобразиться все данные выбранной услуги.

### 5.8 Изменение кнопки назад

Перезагрузим услугу при отмене изменения (кнопка назад):
```cs
private void goBack(object sender, RoutedEventArgs e)
{
    if (Service.Id != 0)
    {
        Session.Instance.Context.Entry(Service).Reload();
    }
    NavigationService.GoBack();
}
```

Это позволит загрузить из базы данных старые значения, откатив таким образом все изменения.

### 5.9 Сохранение

Добавим обработчик события для кнопки сохранения изменений:
```cs
        private void saveChanges(object sender, RoutedEventArgs e)
        {
            if (Service.Id == 0)
            {
                Session.Instance.Context.Add(Service);
            }

            try
            {
                Session.Instance.Context.SaveChanges();
				MessageBox.Show("Данные сохранены.");
                NavigationService.GoBack();
            }
            catch
            {
                MessageBox.Show("При сохранении данных возникла ошибка!");
                if (Service.Id == 0)
                {
                    Session.Instance.Context.Remove(Service);
                }
            }
        }
```

Проверьте работоспособность, выполнив добавление и изменение.

**Самостоятенльно** добавьте проверки валидности введенных данных (отсутствие пустых полей, корректное значение стоимости).

### 5.10 Добавление изображения

При добавлении изображения выполним копирование файла согласно заданию. Выбор файла пользователь будет осуществлять с помощью стандартного системного диалога. При копировании будем задавать файлу случайное имя для избежания коллизий (одинаковых имен).

Код обработчика событий:
```cs
private void updateImage(object sender, RoutedEventArgs e)
{
    // экземпляр OpenFileDialog для вызова диалогового окна
    var dialog = new OpenFileDialog
    {
        Filter = "Png Images|*.png"
    };

    // вызываем окно, проверяем, что файл был успешно выбран
    var result = dialog.ShowDialog();
    if (result != true)
    {
        return;
    }

    // генерируем случайное имя файла
    string newFilename = Guid.NewGuid().ToString().Replace("-", "") + ".png";
    // и путь для копирования
    string pathToCopy = $"Assets/Images/Services/{newFilename}";

    // выполняем копирование и записываем значение в Service.MainImagePath
    try
    {
        File.Copy(dialog.FileName, pathToCopy);
        Service.MainImagePath = newFilename;
    }
    catch
    {
        MessageBox.Show("Ошибка при копировании файла!");
    }
}
```

Если запустить программу и попробовать изменить изображение, то оно изменится, однако мы не увидем изменений в интерфейсе (нужно будет обновить записи, изменив поисковую строку/фильтры).

Исправим это. Сперва добавим для услуги интерфейс:
```cs
public partial class Service : INotifyPropertyChanged 
{
...
}
```

Реализуем его:
```cs
public event PropertyChangedEventHandler? PropertyChanged;

private void notifyPropertyChanged(string propertyName)
{
    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
```

Преобразуем свойство для изображения в полное:
```cs
private string? mainImagePath;

...

public string? MainImagePath
{
    get => mainImagePath;
    set
    {
        mainImagePath = value;
        notifyPropertyChanged(nameof(MainImagePath));
    }
}
```

Если все было сделано правильно, то изображение на странице изменения будет изменяться сразу же при выборе нового файла.

### 5.10 Добавление дополнительного изображения

Сперва изменим тип коллекции для дополнительных фотографий (класс `Service`):
```cs
    public virtual ICollection<ServicePhoto> ServicePhotos { get; } 
        = new ObservableCollection<ServicePhoto>();
```

Далее, выполним загрузку изображений при изменении записи:
```cs
// public UpdateServicePage() ...
if (Service.Id == 0)
{
    headerLabel.Content = "Добавление услуги";
}
else
{
    headerLabel.Content = "Изменение услуги";
    Session.Instance
        .Context
        .Services
        .Entry(service)
        .Collection(s => s.ServicePhotos).Load();
}
```

Привяжем коллекцию к заготовленному `ItemsControl`:
```xml
<ItemsControl ItemsSource="{Binding Service.ServicePhotos}">
    <ItemsControl.ItemsPanel>
        <ItemsPanelTemplate>
            <WrapPanel ItemHeight="75" ItemWidth="75" />
        </ItemsPanelTemplate>
    </ItemsControl.ItemsPanel>
    <ItemsControl.ItemTemplate>
        <DataTemplate>
            <Image Source="{Binding PhotoPath, Converter={StaticResource imageConverter}}" />
        </DataTemplate>
    </ItemsControl.ItemTemplate>
</ItemsControl>
```

Напишем обработчик событий для кнопки добавления:
```cs
private void addServicePhoto(object sender, RoutedEventArgs e)
{
    var dialog = new OpenFileDialog
    {
        Filter = "Png Images|*.png"
    };

    var result = dialog.ShowDialog();
    if (result != true)
    {
        return;
    }

    string newFilename = Guid.NewGuid().ToString().Replace("-", "") + ".png";
    string pathToCopy = $"Assets/Images/Services/{newFilename}";

    try
    {
        File.Copy(dialog.FileName, pathToCopy);
        var photo = new ServicePhoto { Service = this.Service, PhotoPath = newFilename };
        Service.ServicePhotos.Add(photo);
    }
    catch
    {
        MessageBox.Show("Ошибка при копировании файла!");
    }
}
```

Проверьте работоспособность.

### 5.11 Откат добавления изображений

На данном этапе изображения не исчезают при нажатии на кнопку назад. Поскольку мы используем контекст (`DbContext`) не совсем правильно (он не должен быть долгоживущим, а мы имеем единстенный экземпляр на все приложение), вопрос перезагрузки коллекции является непростым:
https://stackoverflow.com/questions/65723105/replacing-a-entity-collection-in-entity-framework-core-causes-dbcontext-to-fetch
https://github.com/dotnet/efcore/issues/16186
https://github.com/dotnet/efcore/issues/13620

Чтобы решить данную проблему, используем несколько "костыльное" решение. Сперва добавим приватный список:
```cs
private List<ServicePhoto> newPhotos = new();
```

Изменим код обработчика `addServicePhoto`:
```cs
...
try
{
    File.Copy(dialog.FileName, pathToCopy);
    var photo = new ServicePhoto { Service = this.Service, PhotoPath = newFilename };
    Service.ServicePhotos.Add(photo);
    newPhotos.Add(photo);
}
...
```

И код кнопки "Назад":
```cs
private void goBack(object sender, RoutedEventArgs e)
{
    if (Service.Id != 0)
    {
        foreach (var photo in newPhotos)
        {
            Service.ServicePhotos.Remove(photo);
        }
        Session.Instance.Context.Entry(Service).Reload();
    }

    NavigationService.GoBack();
}
```

Проверьте работоспособность. Добавленные изображения не должны снова загружаться при нажатии на кнопку "Назад".

### 5.12 Рефакторинг

**Самостоятельно** выполните рефакторинг кода. Вынесите повторяющиеся фрагменты кода в`updateImage` и `addServicePhoto` в отдельный метод (например, отвечающий за копирование файла).

### 5.13 Удаление дополнительного изображения

Измените разметку для элемента внутри `ItemsControl` с дополнительными изображениями:
```cs
<ItemsControl.ItemTemplate>
    <DataTemplate>
        <Grid>
            <Image Source="{Binding PhotoPath, Converter={StaticResource imageConverter}}" />
            <Button VerticalAlignment="Top" HorizontalAlignment="Right"
                    Padding="0"
                    Height="20"
                    Width="20"
                Style="{DynamicResource MaterialDesignFlatLightButton}" Content="x" />
        </Grid>
    </DataTemplate>
</ItemsControl.ItemTemplate>
```

**Самостоятельно** реализуйте удаление дополнительного изображения по нажатию на кнопку (не надо удалять сами файлы, только записи в БД).

## 6 Запись клиента

### 6.1 Создание страницы

Добавьте страницу для записи на услугу. Реализуйте простой макет:
```xml
<StackPanel >
    <Label Content="Запись на услугу" FontSize="35" Margin="0 0 0 25" />
    <StackPanel Margin="10">
        <Label Content="Клиент" />
        <ComboBox />
        <Label Content="Услуга" />
        <ComboBox />
        <Label Content="Дата записи" />
        <DatePicker IsTodayHighlighted="True" />
        <Label Content="Время записи" />
        <materialDesign:TimePicker Is24Hours="True" />
        <Button Margin="0 20" Content="Записать" />
    </StackPanel>
</StackPanel>
```


Для того, чтобы использовать компоненты `MaterialDesign` добавьте строку (в свойствах страницы):
```xml
xmlns:materialDesign="http://materialdesigninxaml.net/winfx/xaml/themes"
```

Реализуйте переход на страницу, добавив обработчик нажатия на кнопку записи (в окне услуг):
```cs
private void goToRegistrationPage(object sender, RoutedEventArgs e)
{
    var service = (sender as Button)?.DataContext as Service;
    if (service == null) return;
    NavigationService.Navigate(new ServiceRegistrationPage(service));
}
```

Также, измените конструктор страницы записи:
```cs
    public partial class ServiceRegistrationPage : Page
    {
        public Service Service { get; set; }

        public ServiceRegistrationPage(Service service)
        {
            InitializeComponent();
            Service = service;
        }
    }
```

### 6.2 Загрузка услуг

Выполним загрузку списка услуг. Сперва добавим свойство:
```cs
public List<Service> Services { get; set; }
```

Выполним загрузку значений из базы данных:
```cs
Services = Session.Instance.Context.Services.ToList();
```

Для удобства поиска загрузим значения в отсортированном виде:
```cs
Services = Session.Instance.Context.Services.OrderBy(s => s.Title).ToList();
```

*Зададим в качестве контекста привязки само окно* (самостоятельно через код C# или XAML).

Выполним привязку:
```xml
<ComboBox ItemsSource="{Binding Services}">
    <ComboBox.ItemTemplate>
        <DataTemplate>
            <TextBlock>
                <Run Text="{Binding Title}" /> |
                <Run Text="{Binding CostWithDiscount, Mode=OneWay, StringFormat={}{0:0.00}}" /> р. за
                <Run Text="{Binding DurationInMinutes, Mode=OneWay}" /> мин.
            </TextBlock>
        </DataTemplate>
    </ComboBox.ItemTemplate>
</ComboBox>
```

Чтобы выбранная услуга была сразу же указана в соответствующем `ComboBox` добавим привязку для свойства `SelectedItem`:
```xml
<ComboBox ItemsSource="{Binding Services}" SelectedItem="{Binding Service}">
    <ComboBox.ItemTemplate>
    	...
```

Проверьте работоспособность. При загрузке страницы должны быть корректно отображены все услуги.

### 6.3 Загрузка клиентов

Добавьте свойства:
```cs
public Client Client { get; set; }

public List<Client> Clients { get; set; }
```

**Самостоятельно** выполните загрузку значений в `ComboBox` и привязку текущего выбранного элемента к свойству `Client`.

### 6.4 Дата и время

Настроим элементы для выбора времени. Зададим им имена: `serviceDatePicker` и `serviceTimePicker`. В коде конструктора зададим начальные даты и ограничения:
```cs
serviceDatePicker.DisplayDateStart = DateTime.Today; // нельзя выбрать даты до сегодняшнего дня
serviceDatePicker.SelectedDate = DateTime.Today; // выбран сегодняшний день
serviceTimePicker.SelectedTime = new DateTime().AddHours(12); // выбрано время 12:00
```

Теперь при открытии страницы записи, будет показано сегодняшнее число и время 12:00.

**Самостоятельно** добейтесь того, чтобы было показано время, превышающее на час текущее, со значением минут и секунд равным нулю.
Примеры:
```
00:55 -> 1:00
12:01 -> 13:00
15:00 -> 16:00
13:31 -> 14:00
```

### 6.5 Добавление записи

Напишем обработчик для кнопки добавления записи:
```cs
private void registration(object sender, RoutedEventArgs e)
{
    var time = serviceTimePicker.SelectedTime.Value;
    var date = serviceDatePicker.SelectedDate.Value;

    // складываем дату и время
    var startTime = date.AddTicks(time.Ticks);

    // создаем запись
    var clientService = new ClientService
    {
        Client = this.Client,
        Service = this.Service,
        StartTime = startTime
    };

    // сохраняем ее в бд
    Session.Instance.Context.ClientServices.Add(clientService);
    try
    {
        Session.Instance.Context.SaveChanges();
        MessageBox.Show("Клиент записан!");
        NavigationService.GoBack();
    }
    catch
    {
        MessageBox.Show("Ошибка при записи клиента!");
        Session.Instance.Context.ClientServices.Remove(clientService);
    }
}
```

В целом, это должно работать.

### 6.6 Кнопка назад

**Самостоятельно** реализуйте кнопку "Назад".

### 6.7 Необязательный комментарий

Предполагается наличие необязательного комментария для каждой записи (см. базу данных). Добавьте на странице записи еще одно поле, предназначенное для сохранения комментария.

## 7 Ближайшие записи

**Самостоятельно** реализуйте окно с ближайшими записями (см. файл с заданием).

## 8 Сохранение проекта

Сохраните проект на gogs. Добавьте файл **README.MD**. Для заполнения readme используйте шаблон, данный в папке с заданием (README-Template_rus.md).