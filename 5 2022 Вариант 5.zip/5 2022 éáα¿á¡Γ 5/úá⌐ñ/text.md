# Вариант 5

## 1 Начало работы

> **Примечание:**
> код и используемые ниже подходы зачастую не стоит брать как хороший пример для реальных проектов,
> все написано так,  чтобы побыстрее и попроще выполнить задание на экзамене.


Внимательно изучите содержимое каталогов. Прочитайте файл с заданием "Сессия1". Выпишите все функции (задачи) на листок бумаги или в текстовый документ. Потратив время на описание всех функций, вы уменьшите шанс того, что что-нибудь просто напросто забудете.

Примерный вид (во время экзамена вы можете описать все менее детально, учитывайте дефицит времени. Так или иначе вам все равно придется вовзращаться к тексту задания):
- восстановление базы из скрипта;
- нормализация базы данных, создание новых таблиц и связей;
- импорт данных;
-- импорт товаров;
-- импорт заказов;
-- импорт пользователей;
- окно авторизации;
-- проверка логина и пароля;
-- реализация входа по ролям;
-- передача информации о пользователе в окно (вывод ФИО);
-- вход в гостевом режиме;
-- CAPTCHA (буквы и цифры, не в ряд, зачернуты или шум);
-- блокировка на 10 секунд при неудачном входе с использование CAPTCHA;
- список товаров;
-- вывод товаров;
-- соответствие макету;
-- поиск товара (по нескольким аттрибутам);
-- сортировка (по убыванию или возрастанию стоимости);
-- фильтр по производителю (в списке первым пунктом идет "все производители");
-- совместная работа фильтров;
-- вывод количества записей (N из M записей);
-- удаление товара (товар, который есть в заказе удалить нельзя; товар удаляется вместе с допонительными товарами);
-- переход на окно добавления;
-- переход на окно изменения;
- добавление и редактирование;
-- доступно только администратору;
-- поля (наименование, категория (выпадающий список), количество на складе, единица измерения, поставщик, стоимость за единицу, изображение и подробное описание (с возможностью многострочного ввода))
-- стоимость не может быть отрицательной, выводится с точностью до сотых;
-- минимальное количество не может быть отрицательным;
-- при открытии формы для редактирования все поля выбранного объекта должны быть подгружены в соответствующие поля из базы данных;
-- ID товара при добавлении не отображается, автоматически вычисляется +1 к имеющемуся в БД, при редактировании ID доступно только для чтения;
-- изменение изображение товара (сразу отображается, максимальный размер 300х200 пикселей);
-- при замене изображения, старое будет удалено из папки;
-- значения в списке должны автоматически обновляться;
- разработка библиотеки;
-- название библиотеки;
-- имя класса;
-- сигнатура метода;
-- алгоритм;
- разработка юнит-тестов;
-- создание проекта;
-- задание зависимости;
-- написание тестов (имена тестов, логика тестов);
- ручное тестирование;
- 5 сценариев по шаблону, тестирование добавления товара;
- сохранение;
-- сохранение файлов;
-- создание readme.md

## 2 База данных

### 2.1 Восстановление БД

Выполните сохранение базы из скрипта. Для этого, сперва авторизуйтесь на сервере (используем SSMS). Далее, вы можете открыть файл скрипта (с помощью соответствующего пункта меню или drag-n-drop).

В зависиомости от рабочего места и используемого сервера у вас может быть доступ ко всем БД или к конкретно вашей. Так или иначе, убедитесь, что вы работаете с правильной базой данных. Вероятно, что вам придется изменить некоторые инструкции в скрипте (вроде `CREATE` или `USE` )
![](1.png)
![](2.png)

По нажатию на кнопку "выполнить" вы добъетесь выполнения скрипта. Обратите внимание: чтобы обновить значения в окне "обозреватель объектов", вам придется нажать на кнопку "обновить".
Создейте диаграмму БД (ПКМ по "Диграммы баз данных", создать диаграмму). 
![](3.png)

Для изменения полей таблиц вы можете поступить двумя способами. Первый - использовать "проектирование":
![](4.png)

Второй - можно редактировать поля прямо на диаграмме:
![](5.png)
---
![](6.png)

Для ускорения процесса проектирования будем все проделывать прямо на диаграмме. В обычной ситуации (не на экзмене), лучше не торопиться и работать через "проектирование".

### 2.2 Анализ и импорт таблиц

Самое время проанализировать задание, файлы для импорта, и сопоставить их с существующей базой данных.
Пользователи:
![](7.png)

В базе данных мы имеем практически те же самые поля, однако:
- ФИО нужно разбить на три столбца;
- роль сотрудника нужно вынести в отдельную таблицу;

Первая проблема решается с помощью функции Excel "текст по столбцам" (или как-то так). Вам придется разобраться с ней самостоятельно, так как на моей машине нет MS Office.

В LibreOffice это выглядит примерно так (в Excel будет все очень похоже):
![](8.png)
![](9.png)
![](10.png)

Вторая проблема решается следующим образом. Сперва определим все роли. Если ролей и записей немного, то мы можем это сделать просто посмотрев на таблицу. Если записей достаточно много, то лучше скопировать значения из столбца в другое место и воспользоваться функцией Excel "данные -> удалить дубликаты".

В принципе, мы сразу же видим, что роли всего три (плюс, что даже важнее, об этом можно прочитать в задании). Добавим роли в таблицу Role вручную (SSMS, использовать "изменить первые 200 строк"):
![](12.png)
![](11.png)

Далее, с помощью "поиск и замена" (CTRL-F), выполним замены по столбцу (заменяйте роли на тот Id, который сгенерировался **у вас**, у меня идентификаторы попали на числа 1, 2 и 3).
![](13.png)
![](14.png)

Чтобы быстро импортировать данные, используем простое копирование из Excel.
Сперва откройте окно изменения записей (таблица User)
![](15.png)

Далее, добейтесь того, чтобы столбцы в Excel совпадали со столбцами в БД:
![](16.pnG)

Выделите диапазон вместе с предполагаемым полем Id (из-за автоинкремента вставка в первый столбец будет недоступна, но мы все равно должны его учесть).
![](17.png)

Выполните вставку в SSMS, предварительно выделив запись:
![](18.png)
![](19.png)

Следующей таблицей выберем товары. 
![](20.png)

Проанализировав таблицу в БД и задание, мы можем отметить следующее:
- артикул выступает первичным ключом, но по заданию должен быть ID, увеличивающийся на единицу;
- в БД отсутствует поле с единицей измерения;
- в БД отсутствует поле с поставщиками;
- в БД отсутствует поле с максимальной скидкой; 
- производителей, категории товара и единицы измерения следует вынести в отдельные таблицы;
- поле с изображением имеет бинарный тип image, по заданию же необходимо хранить путь до файла;


Изменим первичный ключ. 
Сперва добавим поле (через диаграмму, ПКМ -> вставить столбец):
![](21.png)

Затем удалим старый первичный ключ (ПКМ по полю ProductArcticle -> удалить первичный ключ; при этом будет удалена связь с таблицей OrderProduct!)
![](22.png)

Зададим новый первичный ключ (ПКМ -> задать первичный ключ) и установим автоинкремент (через свойства поля, ПКМ -> свойства):
![](23.png)

Добавим единицы измерения. Cоздадим отдельную таблицу, зададим ей первичный ключ и автоинкремент
![](24.png)
![](25.pnG)

Добавим существующие единицы измерения:
![](26.png)

Выполним замену в файле для импорта:
![](27.png)

Создадим поле в таблице с продуктами:
![](28.png)

Добавим связь. Для этого можно просто "взять" мышкой поле `ProductUnit` и перетащить его на таблицу `Unit`
![](29.png)
а затем задать внешний ключ
![](30.png)
![](31.png)

**Самостоятельно** проделайте похожие действия с производителями и категориями. А именно:
- создайте отдельные таблицы `Manufacturer` и `Category`, задайте первичные ключи и поля с названиями;
- добавьте в базу всех производителей и категории из файла для импорта (используйте удаление дубликатов или просмотрите таблицу вручную);
- с помощью поиска и замены выполните замену всех названий категорий и производителей на идентификаторы (в файле с данными для импорта);
- задайте связь между таблицами.

Примерный результат:
![](32.png)
![](33.png)
![](34.png)
![](35.pNg)

**Самостоятельно** добавьте таблицу поставщиков, выполнив действия, указанные выше, еще раз.
![](36.png)
![](37.png)
![](38.png)


После нормализации данных (успешного создания всех таблиц и связей), наша следующая проблема - поле Image. При попытке изменить его на nvarchar можно увидеть следующее сообщение:
![](39.png)

Решение является очень простым: нужно удалить поле и создать его снова, указав при этом тип nvarchar.

Также, на забудьте про поле `ProductMaxDiscountAmount` (максимальная скидка).

Последняя проблема - поле `ProductStatus`. Здесь имеется подстава от авторов задания. Дело в том, что в задании или ресурсах мне не удалось найти никакой информации о статусах продуктов. При этом есть критерий, связанный с проверкой наличия данного поля в окне добавления (а по заданию такое поле не требуется!). В общем, предложение следующее: просто удалить это поле как ненужное. Надеемся, что таких неточностей в задании в будущем не возникнет.


Когда все будет наконец готово, выполните копирование значений из таблицы в БД (по аналогии с импортом пользователей):
- сперва приведите в соответствие порядок полей;
- затем выполните копирование и вставку в окно "изменить первые 200 записей";

Кстати, если не хотите двигать поля в excel, никто не мешает изменить порядок полей в SSMS.

![](40.PNG)


Последняя таблица - таблица с заказами.
![](41.png)

Сразу бросается в глаза следующее:
- статус заказа следует вынести в отдельную таблицу;
- клиента следует задать через связь с таблицей user;
- необходимо имортировать пункты выдачи;
- состав заказа следует реализовать через промежуточную таблицу `OrderProduct`;
- не хватает даты заказа (есть только дата доставки) и кода получения;

Начнем с импорта пунктов выдачи.
![](42.png)

В принципе, вы легко можете разбить адрес с помощью функции "текст по столбцам". Я этого делать не буду и просто оставлю все как есть.

Создаем таблицу для пунктов выдачи, определяем необходимые поля и добавляем связь.
![](43.png)

С помощью обычного копирвания импортируем данные в таблицу.
![](44.png)

Если у вас, как и у меня, идентификаторы идут не с единицы, и вам нужно изменить их значения, вы можете просто выполнить SQL-запрос:
```sql
-- вместо 10000 вы можете подогнать ваше число
UPDATE PickupPoint SET PickupPointId = PickupPointId - 10000;
```

Со статусами заказов вы уже знаете что делать и легко справитесь **самостоятельно**.
![](45.png)

Далее, добавим отношение между таблицами `Order` и `User`:
![](46.png)
И сразу же изменим значения в файле для импорта:
![](47.png)

Последнее, что осталось - это состав заказа. Сперва будет удобным вынести информацию на отдельный лист
![](48.png)

Далее, с помощью "текст по столбцам" и других функций Excel добейтесь, чтобы ваши данные были преобразованы к следующему виду:
![](49.png)

В принципе, мы можем заменить товары на их Id с помощью все той же замены, но что делать если записей будет очень много?

Решением может быть использование функции Excel ВПР. Сперва подготовим таблицу для поиска. Выполним с помощью SSMS запрос:
```sql
SELECT ProductArticleNumber, ProductId FROM Product
```
![](50.png)

Полученные значения вставим в Excel
![](51.png)

В ячейке J2 (ну или где-нибудь правее, как вам удобнее) напишем формулу `=A2` (значение из столбца Заказ)
В ячейке L2 (через одну) напишем `=C2`(значение из столбца Количество)
В ячейке K2 (между ними) нажмем на мастер функций:
![](52.png)
В окне выбора функции найдем функцию ВПР и выберем ее. Далее, следует задать следуюшее (в Excel названия могут отличаться по сравнению с моей программой):
- критерий поиска (какое значение искать);
- таблица для поиска (где искать);
- номер столбца в таблице для получения результата (что выбрать из таблицы в случае успеха);
- является ли диапазон отсортированным (в нашем случае ЛОЖЬ. Вообще, лучше искать по отсортированным диапазонам, но мы просто экономим время)

В критерии поиска указываем артикул. В таблице для поиска указывам диапазон, содержащий информацию о продуктах (так как мы ищем по артиклу, он должен быть в этом диапазоне первым столбцом). Номер столбца берем 2 (второй столбец содержит Id, нумерация здесь с единицы). 
![](53.png)

После написания формулы раскопируем значения:
![](54.png)

Полученные справа числа мы сможем вставить в таблицу `OrderProduct`.

Осталось еще немного изменить саму таблицу `Order`:
- изменим поле с `ProductArticleNumber` на `ProductId` типа int;
- создадим связь между `OrderProduct` и `Product`;
- если пропал первичный ключ (скорее всего это не случилось), то нужно задать составной первичный ключ, для этого вам нужно выделить оба поля `OrderId` и `ProductId`, после чего добавить первичный ключ (ключик будет нарисован рядом с обоими полями, уникальным становится не отдельное значение `OrderId` или `ProductId`, а их пара).
Примерный результат:
![](55.png)

Последний штрих - добавим поле `OrderDate` типа `DateTime` и поле `OrderCode` типа `int`:
![](56.pnG)

Наконец, можно начать сам импорт. Упорядочим столбцы (вам нужно упорядочить под свои полученные поля):
![](57.png)

Выполним копирование:
![](58.png)

После этого можно вставить полученные ранее значения для `OrderProduct`:
![](59.pnG)

Готово! Мы завершили проектирование БД и выполнили импорт данных.

![](60.png)

## 3. Создание приложения

### 3.1 Начальные приготовления

Создайте проект WPF (Майкрософт). Выберите последнюю доступную версию платформы .Net. Проект нужно назвать по названию организации (см. файл требования и рекомендации). Я назову свой проект `Tkani`.

Выполните установку пакетов с помощью NuGet:
```
Microsoft.EntityFrameworkCore
Microsoft.EntityFrameworkCore.Tools
Microsoft.EntityFrameworkCore.SqlServer
```
![](61.png)

Далее, откройте консоль диспетчера пакетов NuGet и напишите команду:
```
Scaffold-DbContext "ВАША СТРОКА ПОДКЛЮЧЕНИЯ" Microsoft.EntityFrameworkCore.SqlServer -out Models
```
В кавычках вам следует написать строку подключения. У меня это будет `"Server = (localdb)\MSSQLLocalDB; Database = Tkani; Integrated Security = true"`. У вас же строка может отличаться. В случае с локальной базой `Tkani` подойдет моя строка. В случае с базой на удаленном сервере ваша строка может иметь вид `"Server = 192.168.200.247; Database = Student21; User Id = Student21; Password=mymegapassword"`.

Выполните команду. Если все было проделано правильно, то будет сгенерирована папка Models со всеми необходимыми классами.
![](62.png)

Сразу же вынесем `MainWindow` в каталог `Views`:
![](63.png)

После этого переименуем окно в `LoginWindow`.

Запустите приложение. Возникнет ошибка. Исправим ее, изменив `StartupUri` в файле `App.xaml`:
```xml
<Application x:Class="Tkani.App"
			 ...
             StartupUri="Views/LoginWindow.xaml">
    <Application.Resources>
...
```

Сразу зададим иконку из ресурсов (она имеет расширение ico). Для этого следует нажать ПКМ по проекту, выбрать пункт Свойства. В окне свойств нужно найти пункт "Значок" и выбрать соответствующий файл.
![](64.png)

### 3.2 Окно авторизации

Разработаем окно авторизации.
Сперва добавим логотип
![](65.png)
и установим его как ресурс
![](66.png)

Окну установим `WindowStyle="ToolWindow"` и `ResizeMode="NoResize"`. Зададим размеры 400x500. 

Основным компоновочным элементом возьмем `Grid`:
```xml
<Grid VerticalAlignment="Center" Margin="10 0">
    <Grid.RowDefinitions>
        <RowDefinition Height="180" />
        <RowDefinition Height="auto" />
    </Grid.RowDefinitions>
    <Image Source="./../Images/logo.png" HorizontalAlignment="Center" />
    <StackPanel Grid.Row="1">
        ...
    </StackPanel>
</Grid>
```
Первая строка будет содержать изображение, вторая строка будет содержать `StackPanel` с полями ввода. 

Добавим внутрь `StackPanel` сами поля ввода:
```xml
<Label Content="Имя пользователя" />
<TextBox />
<Label Content="Пароль" />
<PasswordBox />
<StackPanel Margin="0 10 0 25">
	<StackPanel HorizontalAlignment="Center" Orientation="Horizontal">
        <TextBlock Text="1A" x:Name="captchaFirstBlock"
                   TextDecorations="Strikethrough" Margin="0 5 10 0" />
        <TextBlock Text="z8" x:Name="captchaSecondBlock"
                   TextDecorations="Strikethrough" />
    </StackPanel>
    <TextBlock Text="Введите текст с картинки:" />
    <TextBox />
</StackPanel>
<Button Content="Вход в систему" />
```
Элементы, связанные с captcha мы разместили в отдельный контейнер (еще одна `StackPanel`), чтобы их было проще спрятать или показать (достаточно будет просто задать `Visibility` всему контейнеру).

При запуске, на данном этапе, окно выглядит примерно следующим образом:
![](67.png)

Чтобы сделать его более симпатичным мы обратимся к руководству по стилю и опишем ресурсы в файле app.xaml.
```xml
<!--Цвета-->
<SolidColorBrush x:Key="BackgroudColor" Color="#FFFFFF" />
<SolidColorBrush x:Key="AdditionalColor" Color="#76E383" />
<SolidColorBrush x:Key="AccentColor" Color="#498C51" />
<!--Шрифт-->
<Style TargetType="Window">
    <!-- Сами Window и Page имеют свойство FontFamily -->
    <!-- Это самый быстрый способ задать шрифт для множества элементов, -->
    <!-- но при таком подходе надо быть внимательней -->
    <Setter Property="FontFamily" Value="Comic Sans MS" />
</Style>
<!--Кнопки-->
<Style TargetType="Button" >
    <Setter Property="Padding" Value="5" />
    <Setter Property="Background" Value="{StaticResource AccentColor}" />
    <Setter Property="Foreground" Value="{StaticResource BackgroudColor}" />
</Style>
<!--Поля ввода-->
<Style TargetType="TextBox">
    <Setter Property="Padding" Value="0 5" />
    <Setter Property="VerticalContentAlignment" Value="Center" />
    <Setter Property="BorderBrush" Value="{StaticResource AccentColor}"  />
    <Setter Property="Background" Value="{StaticResource AdditionalColor}" />
</Style>
<Style TargetType="PasswordBox">
    <Setter Property="Padding" Value="0 5" />
    <Setter Property="VerticalContentAlignment" Value="Center" />
    <Setter Property="BorderBrush" Value="{StaticResource AccentColor}"  />
    <Setter Property="Background" Value="{StaticResource AdditionalColor}" />
</Style>
```

Во время экзамена можете сильно не усердствовать, однако, вам в любом случае нужно будет определить шрифты и цвета.

Немного изменим разметку окна, добавив элементам имена и скрыв контейнер для captcha:
```xml
<Window x:Class="Tkani.LoginWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
        xmlns:local="clr-namespace:Tkani"
        mc:Ignorable="d"
        WindowStyle="ToolWindow"
        WindowStartupLocation="CenterScreen"
        Background="{StaticResource AdditionalColor}"
        ResizeMode="NoResize"
        Title="ООО Ткани - Вход в систему" Height="500" Width="400">
    <Grid VerticalAlignment="Center" Margin="10 0" >
        <Grid.RowDefinitions>
            <RowDefinition Height="180" />
            <RowDefinition Height="auto" />
        </Grid.RowDefinitions>
        <Image Source="./../Images/logo.png" HorizontalAlignment="Center" />
        <StackPanel  Grid.Row="1">
            <Label Content="Имя пользователя" />
            <TextBox Name="loginInput" />
            <Label Content="Пароль" />
            <PasswordBox Name="passwordInput" />
            <StackPanel Margin="0 10 0 25" x:Name="captchaContainer" Visibility="Ршввут">
                <StackPanel HorizontalAlignment="Center" Orientation="Horizontal">
                    <TextBlock Text="1A" x:Name="captchaFirstBlock"
                               TextDecorations="Strikethrough" Margin="0 5 10 0" />
                    <TextBlock Text="z8" x:Name="captchaSecondBlock"
                               TextDecorations="Strikethrough" />
                </StackPanel>
                <TextBlock Text="Введите текст с картинки:" />
                <TextBox />
            </StackPanel>
            <Button Content="Вход в систему" />
        </StackPanel>
    </Grid>
</Window>
```

Для удобства использования поместим при создании окна фокус в поле ввода имени:
```cs
public LoginWindow()
{
    InitializeComponent();
    loginInput.Focus(); // установка фокуса
}
```

И сделаем так, чтобы кнопка входа срабатывала на Enter (зададим свойство `IsDefault` в `True`):
```xml
<Button IsDefault="True" Content="Вход в систему" />
```

В принципе, теперь мы готовы писать логику входа. Определим обработчик события `Click` кнопки входа. Для этого можно написать название метода внутри разметки
```xml
<Button IsDefault="True" Content="Вход в систему" Click="login" />
```
поставить курсор(каретку) внутрь названия `login` и нажать F12. Сгенерируется метод на языке C#:
```cs
private void login(object sender, RoutedEventArgs e)
{
	
}
```

Напишем код:
```cs
private void login(object sender, RoutedEventArgs e)
{
    var context = new TkaniContext();
    var user = context
        .Users
        .FirstOrDefault(u => u.UserLogin == loginInput.Text && u.UserPassword == passwordInput.Password);

    if (user is null)
    {
        MessageBox.Show("Неверный логин или пароль. Проверьте введенные данные",
            "Ошибка входа",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
        return;
    }

    // ниже будет логика перехода на другие окна
    MessageBox.Show("Вход успешен");
}
```

В коде выше мы создаем экземпляр `TkaniContext`, после чего используем его свойство `Users`, чтобы работать с коллекцией пользователей. С помощью метода расширения Linq `FirstOrDefault` мы легко находим пользователя, удовлетворяющего заданному в скобках условию (логин и пароль равны тому, что ввел пользователь). В случае, если пользователь не будет найден, в переменной `user` будет лежать значение `null`, что легко позволяет нам сделать простую проверку и вывести сообщение об ошибке входа.

Проверьте работоспособность.

Для упрощения тестирования и отладки целесообразно временно жестко закодировать какого-нибудь пользователя в поля ввода:
```xml
<TextBox Text="8lf0g@yandex.ru" Name="loginInput" />
...
<PasswordBox Password="2L6KZG" Name="passwordInput" />
```

При неудачном входе сразу добавим генерацию captcha:
```cs
if (user is null)
{
    MessageBox.Show("Неверный логин или пароль. Проверьте введенные данные",
        "Ошибка входа", 
        MessageBoxButton.OK,
        MessageBoxImage.Warning);
    updateCaptcha();
    return;
}
```

и напишем соответствующий метод:
```cs
private void updateCaptcha()
{
    const string alphabet = "qwertyuiopasdfghjklzxcvbnm1234567890";

    var rng = new Random();

    captchaFirstBlock.Text = $"{alphabet[rng.Next(alphabet.Length)]}{alphabet[rng.Next(alphabet.Length)]}";
    captchaSecondBlock.Text = $"{alphabet[rng.Next(alphabet.Length)]}{alphabet[rng.Next(alphabet.Length)]}";
    captchaSecondBlock.Margin = new Thickness(0, rng.Next(-10, 10), rng.Next(-10, 10), 0);
    captchaContainer.Visibility = Visibility.Visible;
}
```

В коде метода мы определяем набор доступных символов в переменной `alphabet` и получаем символы в коде с помощью генерации случайного индекса в строке. Также, чтобы получилось интереснее, задаем второй части капчи случайное смещение (с помощью свойства Margin).

Добавим проверку captcha в методе входа:
```cs
private void login(object sender, RoutedEventArgs e)
{
    var context = new TkaniContext();

    string currentCaptcha = captchaFirstBlock.Text + captchaSecondBlock.Text;
    if (captchaInput.Text.Trim() != currentCaptcha)
    {
        MessageBox.Show("Символы с картинки введены неверно! Окно будет заблокировано",
            "Ошибка входа",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
        updateCaptcha();
        return;
    }
    //...
```

Уберем значения `Text` у соответствующих элементов `TextBlock`:
```xml
<TextBlock Text="" x:Name="captchaFirstBlock" 
                               TextDecorations="Strikethrough" Margin="0 5 10 0" />
<TextBlock Text="" x:Name="captchaSecondBlock"
           TextDecorations="Strikethrough" />
```

По сути, получается, что проверка captcha происходит всегда, но при первом вводе ее символы, как и символы в поле ввода, равны пустой строке. Как только будет допущена ошибка, в `TextBlock` появятся символы и пользователь будет вынужден их ввести.

Проверьте работоспособность.

Наконец, выполним блокировку окна. Сперва добавим поля
```cs
private DispatcherTimer timer = new DispatcherTimer
{
    Interval = TimeSpan.FromSeconds(1),
    IsEnabled = false
};
private int blockTime = 10;
```

Затем, мы назначим обработчик на событие Tick.
![](68.png)
---
![](69.png)


Напишем код для таймера:
```cs
private void blockWindow()
{
    IsEnabled = false;
    blockTime = 10;
    timer.Start();
}

private void unblockWindow()
{
    timer.Stop();
    IsEnabled = true;
    loginButton.Content = "Вход в систему";
}

private void Timer_Tick(object? sender, EventArgs e)
{
    if (blockTime == 0)
    {
        unblockWindow();
        return;
    }

    loginButton.Content = blockTime.ToString();
    blockTime--;
}
```


А также вызовем блокировку окна при неверно введенной captcha:
```cs
private void login(object sender, RoutedEventArgs e)
{
    var context = new TkaniContext();

    string currentCaptcha = captchaFirstBlock.Text + captchaSecondBlock.Text;
    if (captchaInput.Text.Trim() != currentCaptcha)
    {
        MessageBox.Show("Символы с картинки введены неверно! Окно будет заблокировано",
            "Ошибка входа",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
        updateCaptcha();
        blockWindow();
        return;
    }
    //...
```

И при неправильном вводе логина и пароля, если captcha была показана:
```cs
if (user is null)
{
    MessageBox.Show("Неверный логин или пароль. Проверьте введенные данные",
        "Ошибка входа", 
        MessageBoxButton.OK,
        MessageBoxImage.Warning);
        if (captchaContainer.Visibility != Visibility.Hidden)
        {
            blockWindow();
        }
        updateCaptcha();
    return;
}
```

Проверьте работоспособность. В случае повторного неправильного ввода логина и пароля, или ввода неверной captcha окно должно быть заблокировано на 10 секунд.

### Дополнительно

- реализуйте возможность показать введенный пароль (отобразить символы по нажатию на кнопку или установки CheckBox).
- увеличьте размеры шрифтов (конечно, можно банально написать на каждом элементе `FontSize`, но может быть есть какой-нибудь более быстрый способ?)

### 3.3 Окно товаров

Сверстайте окно:
![](70.png)

Минимальная ширина окна 1100 пикселей.
Корневой компоновочный элемент - `DockPanel`.
Контейнеры по порядку: `StackPanel`, `Grid` (2 столбца), `StackPanel`. Каждому из контейнеров нужно задать `DockPanel.Dock` в `Top`.
Последним элементом идет `ListView`:
```xml
<ListView x:Name="productsListView">
    <ListView.View>
        <GridView>
            <GridView.Columns>
                <GridViewColumn Width="200" Header="Фотография">
                    <GridViewColumn.CellTemplate>
                        <DataTemplate>
                            <!--Картинка-->
                        </DataTemplate>
                    </GridViewColumn.CellTemplate>
                </GridViewColumn>
                <GridViewColumn Width="500" Header="Общая информация">
                    <GridViewColumn.CellTemplate>
                        <DataTemplate>
                            <!--Макет описания товара-->
                        </DataTemplate>
                    </GridViewColumn.CellTemplate>
                </GridViewColumn>
				<GridViewColumn Width="150" Header="Количество" DisplayMemberBinding="{Binding привяжемколичество}" />
            </GridView.Columns>
        </GridView>
    </ListView.View>
</ListView>
```

Реализуем переход на данное окно (при успешном вводе пользовательских данных и captcha):
```cs
ProductsWindow window = new ProductsWindow();
window.Show();
Close();
```

Выведем данные.

Сперва зададим `ItemsSource`:
```cs
public ProductsWindow()
{
    InitializeComponent();
    var context = new TkaniContext();
    productsListView.ItemsSource = context
        .Products
        .Include(p => p.ProductManufacturerNavigation) // подкачиваем производителей (Inner Join)
        .ToList();
}
```

Далее, выполним все необходимые привязки.
Фото:
```xml
<DataTemplate>
    <Image Source="{Binding ProductPhoto}" />
</DataTemplate>
```

Описание товара:
```xml
<DataTemplate>
    <TextBlock>
        <Run Text="{Binding ProductName}" 
             FontSize="18" FontWeight="Bold" />
        <LineBreak />
        <Run Text="{Binding ProductDescription}" />
        <LineBreak />
        Производитель: <Run Text="{Binding ProductManufacturer}" />
        <LineBreak />
        Цена: <Run Text="{Binding ProductCost}" />
    </TextBlock>
</DataTemplate>
```

Количество:
```xml
<GridViewColumn Width="150" Header="Количество" DisplayMemberBinding="{Binding ProductQuantityInStock}" />
```

При запуске вы должны увидеть примерно следующее:
![](71.png)

Внесем исправления.

Во-первых округлим цену до двух знаков после запятой с помощью `StringFormat`:
```xml
<Run Text="{Binding ProductCost, StringFormat={}{0:0.00} рублей}" />
```
(`{}` задает начало строки, дальше идет шаблон, в котором `{0}` означает само значение, а с помощью двоеточия могут быть заданы параметры конвертации в строку)

Во-вторых заставим текст переноситься на другую строку, указав значение свойству `TextWrapping`:
```xml
<TextBlock TextWrapping="Wrap">
    <Run Text="{Binding ProductName}"
         FontSize="18" FontWeight="Bold" />
    <LineBreak />
    ...
```

В-третьих используем навигационное свойство для вывода названия производителя вместо его Id:
```xml
Производитель: <Run Text="{Binding ProductManufacturerNavigation.Name}" />
```

Кстати, обратите внимание, что названия свойств ваших классов могут отличаться от тех, что в примере. Так или иначе, вам нужно указать свойство, которое будет иметь тип `Manufacturer`, а не `int`.

После всех трех изменений и пары косметических модификаций, получилось примерно следующее:
![](72.png)

Выведем фотографии.

Сперва добавим файлы и зададим им копирование файлов в выходной каталог:
![](73.png)

Также, на забудьте дополнительно добавить картинку-заглушку (есть в папке с ресурсами) и указать для нее все то же самое.

Затем реализуем конвертер. Для этого нужно создать класс:
![](74.png)

Указать, что он реализует интерфейс `IValueConverter`:
![](75.png)

С помощью быстрых действий:
- добавьте using;
- используйте пункт "реализовать интерфейс";
![](76.png)
![](77.png)


Метод Convert
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    throw new NotImplementedException();
}
```
определяет преобразование значения value, которое будет происходить при привязке данных.

Нам нужно просто изменить путь до изображения. Реализуем метод:
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    var filename = value as string;
    if (string.IsNullOrEmpty(filename))
    {
        return System.IO.Path.Combine(Environment.CurrentDirectory, "Images", "picture.png");
    }
    return System.IO.Path.Combine(Environment.CurrentDirectory, "Images", filename);
}
```

Или, если так понятнее, то можно просто "склеить" имена (рекомендуемый подход - через класс `Path`, имеющий встроенные методы для работы с путями и именами файлов):
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    var filename = value as string;
    if (string.IsNullOrEmpty(filename))
    {
        return Environment.CurrentDirectory + @"\Images\picture.png";
    }
    return Environment.CurrentDirectory + @"\Images\" + filename;
}
```

Далее, нужно создать экземпляр конвертера в ресурсах (создадим в app.xaml). Определяем namespace с названием `converters` (название можно выбрать произвольным):
```xml
<Application x:Class="Tkani.App"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:local="clr-namespace:Tkani"
             xmlns:converters="clr-namespace:Tkani.Converters"
             StartupUri="Views/LoginWindow.xaml">
    <Application.Resources>
    ...
```
Используем его, чтобы определить ресурс:
```xml
<Application.Resources>
    <converters:ImagePathConverter x:Key="imageConverter" />

    <!--Цвета-->
    <SolidColorBrush x:Key="BackgroudColor" Color="#FFFFFF" />
    ...
```

Указываем конвертер при привязке:
```xml
<Image Source="{Binding ProductPhoto, Converter={StaticResource imageConverter}}" Width="180" />
```

Примерный результат:
![](78.png)

Реализуем поиск. Для этого напишем обработчик события `TextChanged`:
```xml
<TextBox x:Name="searchTextBox" TextChanged="searchProduct" Margin="10 5" Width="150" />
```

```cs
private void searchProduct(object sender, TextChangedEventArgs e)
{
//...
}
```

При поиске просто отправим новый запрос и получим обновленные результаты:
```cs
private void searchProduct(object sender, TextChangedEventArgs e)
{
    using (var context = new TkaniContext()) // не забываем высвободить ресурсы (Dispose)
    {
        productsListView.ItemsSource = context
            .Products
            .Include(p => p.ProductManufacturerNavigation) // подключаем производителей 
            .Where(p => p.ProductName.Contains(searchTextBox.Text)) // фильтруем их
            .ToList();
    }
}
```

![](79.png)

Реализуем фильтрацию по производителю. Имеем `ComboBox`:
```xml
<ComboBox x:Name="filterComboBox" Margin="10 5" Width="150" />
```

Заполним его элементами:
```cs
public ProductsWindow()
{
    InitializeComponent();
    var context = new TkaniContext();
    productsListView.ItemsSource = context
        .Products
        .Include(p => p.ProductManufacturerNavigation) // подключаем производителей
        .ToList();
    // производители
    var manufacturers = context.Manufacturers.ToList();
    manufacturers.Insert(0, new Manufacturer { Id = 0, Name = "Все производители" });
    filterComboBox.ItemsSource = manufacturers;
}
```

![](80.png)

Добиться вывода названий производителя можно либо написав `ItemTemplate`:
```xml
<ComboBox x:Name="filterComboBox" Margin="10 5" Width="150">
    <ComboBox.ItemTemplate>
        <DataTemplate>
            <TextBlock Text="{Binding Name}" />
        </DataTemplate>
    </ComboBox.ItemTemplate>
</ComboBox>
```
либо установив у `ComboBox` свойство `DisplayMemberPath`
```cs
filterComboBox.DisplayMemberPath = "Name";
```
либо переопределив у класса `Manufacturer` метод `ToString`
(выберите что-то одно).

Реализуем фильтрацию (событие `SelectionChanged` у ComboBox):
```cs
using (var context = new TkaniContext())
{
    var manufacturer = (Manufacturer)filterComboBox.SelectedItem; // выбранный производитель

    if (manufacturer.Id == 0) // все производители
    {
        productsListView.ItemsSource = context
            .Products
            .Include(p => p.ProductManufacturerNavigation)
            .ToList();
    }
    else // производитель имеет Id в БД (какой-то производитель)
    {
        productsListView.ItemsSource = context
            .Products
            .Include(p => p.ProductManufacturerNavigation)
            .Where(p => p.ProductManufacturerNavigation == manufacturer)
            .ToList();
    }
}
```

Осталась сортировка.
Опишем `ComboBox`:
```xml
<ComboBox x:Name="sortingComboBox" Margin="10 5" Width="150" >
    <ComboBoxItem Content="По убыванию цены" />
    <ComboBoxItem Content="По возрастанию цены" />
</ComboBox>
```

Для него также зададим событие `SelectionChanged`:
```cs
private void sortProducts(object sender, SelectionChangedEventArgs e)
{
    using (var context = new TkaniContext())
    {
        if (sortingComboBox.SelectedIndex == 0)
        {
            productsListView.ItemsSource = context
                .Products
                .Include(p => p.ProductManufacturerNavigation)
                .OrderBy(p => p.ProductCost) // по возрастанию цены
                .ToList();
        }
        else if (sortingComboBox.SelectedIndex == 1)
        {
            productsListView.ItemsSource = context
                .Products
                .Include(p => p.ProductManufacturerNavigation)
                .OrderByDescending(p => p.ProductCost) // по убыванию цены
                .ToList();
        }
    }
}
```


Убедитесь в работоспособности всех трех функций.

### Самостоятельно
- добавьте возможность не сортировать значения;
- добейтесь совместной работы поиска, фильтрации и сортировки;
- добейтесь корректного вывода количества найденных записей и записей всего;
- измените макет таким образом, чтобы количество выводилось в центре ячейки;
- сделайте так, чтобы при старте программы, все элементы `ComboBox` не были пустыми;
- реализуйте кнопку выхода, которая бы позволила вернуться на стартовое окно авторизации.

### 3.4 Окно добавления

Создадим кнопку добавления, кнопки изменения и удаления сделаем изначально недоступными:
```xml
<Button Content="Добавить" Margin="5" Width="120" />
<Button Content="Изменить" Margin="5" Width="120" IsEnabled="False" />
<Button Content="Удалить" Margin="5" Width="120" IsEnabled="False" />
```

Далее нужно создать новое окно `AddProductWindow`:
![](81.png)

И сверстать его. Примерный вид:
![](82.png)

Сразу же реализуем переход по нажатию кнопки "Добавить":
```cs
var window = new AddProductWindow();
window.ShowDialog();
```

В окне добавления добавим обработчик `Loaded` (для самого Window), где выполним заполнение всех ComboBox
```xml
Loaded="loadWindow"
```

```cs
private void loadWindow(object sender, RoutedEventArgs e)
{
    using (var context = new TkaniContext())
    {
        unitComboBox.ItemsSource = context.Units.ToList();
        unitComboBox.DisplayMemberPath = "Name";
        categoriesComboBox.ItemsSource = context.Categories.ToList();
        categoriesComboBox.DisplayMemberPath = "Name";
        suppliersComboBox.ItemsSource = context.Suppliers.ToList();
        suppliersComboBox.DisplayMemberPath = "Name";
        manufacturerComboBox.ItemsSource = context.Manufacturers.ToList();
        manufacturerComboBox.DisplayMemberPath = "Name";
    }
}
```

В конструкторе зададим контекст привязки и спрячем поле Id:
```cs
public AddProductWindow()
{
    InitializeComponent();
    currentProduct = new Product();
    DataContext = currentProduct;
    idLabel.Visibility = Visibility.Collapsed;
    idTextBox.Visibility = Visibility.Collapsed;
}
```
Здесь и ниже `currentProduct` - это приватное поле типа `Product`.


Добавим еще один конструктор, чтобы в будущем окно могло также работать для изменения:
```cs
public AddProductWindow(Product product)
{
    InitializeComponent();
    currentProduct = product;
    DataContext = currentProduct;
    idTextBox.IsReadOnly = true;
}
```

Выполним привязку. Пропишем везде соответствующие свойства. Примерный код:
```xml
<Label Content="Id:" Name="idLabel" />
<TextBox x:Name="idTextBox" Text="{Binding ProductId}" />
<Label Content="Артикул:" />
<TextBox Text="{Binding ProductArticleNumber}" />
<Label Content="Наименование:" />
<TextBox Text="{Binding ProductName}" />
<Label Content="Количество:" />
<TextBox Text="{Binding ProductQuantityInStock}" />
<Label Content="Единица измерения:" />
<ComboBox x:Name="unitComboBox" SelectedItem="{Binding ProductUnitNavigation}" />
<Label Content="Категория:" />
<ComboBox x:Name="categoriesComboBox" SelectedItem="{Binding ProductCategoryNavigation}" />
<Label Content="Поставщик:" />
<ComboBox x:Name="suppliersComboBox" SelectedItem="{Binding ProductSupplierNavigation}" />
<Label Content="Производитель:" />
<ComboBox x:Name="manufacturerComboBox" SelectedItem="{Binding ProductManufacturerNavigation}" />
<Label Content="Стоимость:" />
<TextBox Text="{Binding ProductCost}" />
```

```xml
<Image Margin="3" Source="{Binding ProductPhoto,Converter={StaticResource imageConverter}}" />
```

Обратите внимание на следующее:
- у вас названия свойств могут отличаться;
- возможно, что вам будет необходимо также добавить размер скидки (у меня это поле является необязательным);
- возможно, что вам сразу придется добавить поле с описанием товара (у меня это поле является необязательным);

Запустите и проверьте, что отсутствуют ошибки привязки.

Далее, выполним переход на данное окно из окна списка продуктов по нажатию кнопки изменения.

Сперва изменим свойтсва `ListView` и добавим обработчик:
```xml
<ListView x:Name="productsListView" SelectionMode="Single" SelectionChanged="checkSelection">
```

```cs
private void checkSelection(object sender, SelectionChangedEventArgs e)
{
    if (productsListView.SelectedItems.Count > 0)
    {
        updateButton.IsEnabled = true;
        deleteButton.IsEnabled = true;
    }
    else
    {
        updateButton.IsEnabled = false;
        deleteButton.IsEnabled = false;
    }
}
```

или можно упростить:
```cs
private void checkSelection(object sender, SelectionChangedEventArgs e)
{
    bool hasSelectedItems = productsListView.SelectedItems.Count > 0;
    updateButton.IsEnabled = hasSelectedItems;
    deleteButton.IsEnabled = hasSelectedItems;
}
```

Далее, опишем обработчик нажатия на кнопку изменить:
```xml
<Button Content="Изменить" Click="updateProduct" x:Name="updateButton" Margin="5" Width="120" IsEnabled="False" />
```

```cs
private void updateProduct(object sender, RoutedEventArgs e)
{
    Product? selectedProduct = productsListView.SelectedItem as Product;
    if (selectedProduct is not null)
    {
        var window = new AddProductWindow(selectedProduct);
        window.ShowDialog();
    }
}
```

Теперь, при нажатии на кнопку изменения, откроется окно, где будут подгружены все значения полей (кроме ComboBox).

![](83.png)

Наконец, реализуем сохранение:
```xml
<Button Content="Добавить" Click="addUpdateProduct" Margin="0 20 0 10" />
```

```cs
private void addUpdateProduct(object sender, RoutedEventArgs e)
{
	using (var context = new TkaniContext())
    {
        if (currentProduct.ProductId > 0) // изменение
        {
            context.Products.Update(currentProduct);
        }
        else
        {
            context.Products.Add(currentProduct);
        }
        context.SaveChanges();
    }
    Close();
}
```

На первый взгляд, если попробовать выполнить изменение, то все работает хорошо. Однако, при попытке добавления (да и при изменении) могут возникнуть ошибки. Связаны они с тем, что при вызове `Add` происходит попытка добавления, как нового продукта, так и всех связанных с ним данных (производитель, поставшик и др). Причина такого поведения заключется в том, что связанные сущности не отслеживаются контекстом, и он их распознает как просто какие-то незнакомые экземпляры классов. 

В общем, чтобы поменять состояние отслеживания только у основого объекта, стоит просто написать:
```cs
using (var context = new TkaniContext())
{
    if (currentProduct.ProductId > 0) // изменение
    {
        context.Products.Update(currentProduct);
    }
    else
    {
        context.Entry(currentProduct).State = EntityState.Added;
    }
    context.SaveChanges();
}
Close();
```

После нажатия на кнопку данные будут добавлены в БД, однако не будут обновлены в окне вывода товаров. Исправим:
```cs
private void goToAddWindow(object sender, RoutedEventArgs e)
{
    var window = new AddProductWindow();
    window.ShowDialog();
    // просто выполните загрузку записей здесь, после закрытия диалогового окна
}
```
```cs
private void updateProduct(object sender, RoutedEventArgs e)
{
    Product? selectedProduct = productsListView.SelectedItem as Product;
    if (selectedProduct is not null)
    {
        var window = new AddProductWindow(selectedProduct);
        window.ShowDialog();
        // и здесь
    }
}
```

Теперь выполним проверки. Один из вариантов - просто написать кучу `if` (вполне рабочий вариант, вы можете без проблем поступить именно так). Второй вариант использовать аннотации и класс `Validator`.

Сперва определим аннотации (`DataAnnotations`) для нашего типа. Получится что-то вроде:
```cs
public partial class Product
{
    public int ProductId { get; set; }

    [Required]
    [RegularExpression("[A-Z0-9]{6}")]
    public string ProductArticleNumber { get; set; } = null!;

    [Required]
    [StringLength(200, MinimumLength = 2)]
    public string ProductName { get; set; } = null!;

    public int ProductUnit { get; set; }

    public string? ProductDescription { get; set; } = null!;

    public int ProductCategory { get; set; }

    public int ProductManufacturer { get; set; }

    [Required]
    [Range(0, 1000000)]
    public decimal ProductCost { get; set; }

    public byte? ProductMaxDiscountAmount { get; set; }

    public byte? ProductDiscountAmount { get; set; }

    [Required]
    [Range(0, 10000)]
    public int ProductQuantityInStock { get; set; }

    public int? ProductSupplier { get; set; }

    public string? ProductPhoto { get; set; }

    public virtual ICollection<OrderProduct> OrderProducts { get; } = new List<OrderProduct>();

    [Required]
    public virtual Category ProductCategoryNavigation { get; set; } = null!;

    [Required]
    public virtual Manufacturer ProductManufacturerNavigation { get; set; } = null!;

    [Required]
    public virtual Supplier? ProductSupplierNavigation { get; set; }

    [Required]
    public virtual Unit ProductUnitNavigation { get; set; } = null!;
}
```

Далее, добавим проверку:
```cs
private void addUpdateProduct(object sender, RoutedEventArgs e)
{
    // создаем контекст валидации
    var validationContext = new ValidationContext(currentProduct);
    // список ошибок
    var results = new List<System.ComponentModel.DataAnnotations.ValidationResult>();
    // вызываем метод класс Validator - TryValidateObject
    // true для полной проверки
    var isValid = Validator.TryValidateObject(currentProduct, validationContext, results, true);

    // если объект не валидный
    if (!isValid)
    {
        errorsLabel.Content = string.Empty;
        // то выводим все сообщения в специальный label
        // (между полями ввода и кнопкой "добавить")
        foreach (var error in results)
        {
            errorsLabel.Content += error.ErrorMessage + "\r\n";
        }
        return;
    }


    using (var context = new TkaniContext())
    {
        if (currentProduct.ProductId > 0) // изменение
        {
            context.Products.Update(currentProduct);
        }
        else
        {
            context.Entry(currentProduct).State = EntityState.Added;
        }
        context.SaveChanges();
    }
    Close();
}
```

Примерный результат:
![](84.png)

Если хотите изменить текст сообщений, то используйте при объявлении аннотаций специальный параметр `ErrorMessage`:
```cs
[Required(ErrorMessage = "Стоимость товара является обязательной")]
[Range(0, 1000000, ErrorMessage = "Укажите стоимость товара в диапазоне от 0 до 1.000.000")]
public decimal ProductCost { get; set; }
```

Проверьте еще раз работоспособность (с учетом того, что все написано максимально быстро, не уверен, что все хорошо работает).

### Самостоятельно
- добавьте в окне авторизации кнопку гостевого входа;
- в случае, если зашел гость или пользователь, не являющийся администратором, скройте панель с кнопками "добавить", "изменить" и "удалить";
- используя код перехода на окно изменения, реализуйте удаление товара. Перед удалением выведите диалоговое окно (`MessageBox.Show`) с вопросом "Вы уверены, что хотите удалить продукт?". Для удаления могут быть полезными такие методы `DbSet` (внутри вашего контекста) как `Find`, `Remove` и `SaveChanges`;
- измените внешний вид окна (заголовок и название кнопок) в зависимости от того, добавление это или изменение;
- установите фокус в поле названия товара сразу после открытия окна добавления/изменения (исп. метод `SetFocus`);
- реализуйте кнопку "Отменить" в окне добавления/изменения, установите кнопкам "Добавить" и "Отменить" значения свойств `IsDefault` и `IsCancel` соответственно (первая будет работать на Enter, вторая на Esc);
- добавьте в окно добавления многострочное поле с описанием товара;
- добейтесь того, чтобы при открытии окна изменения, все значения также подгружались и в ComboBox.


### 3.5 Изменение изображения

Реализуем изменение/добавление изображения. 

Во-первых, необходимо создать обработчик события `Click` для кнопки "Изменить изображение":
```xml
<Button Grid.Row="1" VerticalAlignment="Top" Content="Изменить изображение" Click="updatePhoto" />
```

```cs
private void updatePhoto(object sender, RoutedEventArgs e)
{

}
```

Во-вторых, по нажатию кнопки вызовем диалоговое окно:
```cs
private void updatePhoto(object sender, RoutedEventArgs e)
{
    OpenFileDialog dialog = new OpenFileDialog
    {
        Filter = "Изображения PNG|*.png",
        Title = "Выбор изображения"
    };

    if (dialog.ShowDialog() == true) // если было выбрано изображение
    {
        // ..
    }

}
```

В-третьих напишем логику. Будем использовать классы `System.IO.Path` и `System.IO.File`:
```cs
private void updatePhoto(object sender, RoutedEventArgs e)
{
    OpenFileDialog dialog = new OpenFileDialog
    {
        Filter = "Изображения PNG|*.png",
        Title = "Выбор изображения"
    };

    if (dialog.ShowDialog() == true) // если было выбрано изображение
    {
        var newPhotoName = Path.GetRandomFileName() + ".png"; // случайное имя файла abcde.png
        var selectedPhoto = dialog.FileName; // полный путь до выбранного пользователем изображения
        var newPhotoFullName = Path.Combine(Environment.CurrentDirectory, "Images", newPhotoName); // полный путь для нового изображения

        File.Copy(selectedPhoto, newPhotoFullName); // копируем файл в каталог с изображениями
        currentProduct.ProductPhoto = newPhotoName; // изменяем фотографию, работает привязка

        // сбросим контекст, чтобы фотография в окне сразу обновилась
        DataContext = null;
        DataContext = currentProduct;
    }
}
```

В целом, добавление изображения после этого должно корректно работать.

### Самостоятельно
- реализуйте удаление файла при замене изображения;
- реализуйте удаление файла (или измените логику добавления) при нажатии на кнопку "Отмена"; 
- реализуйте проверку размеров изображения;


### 3.6 Выделение записей серым цветом

Вернемся к окну вывода товаров.

По заданию необходимо следующее:
> Товары, которых нет на складе, должны отображаться на сером фоне. 

Реализуем данную функциональность с помощью конвертера. Сперва добавим класс (в папку/пространство имен `Converters`):
```cs
public class CountToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
```

Далее напишем логику:
```cs
public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
{
    var count = (int)value;
    if (count == 0)
    {
        return Brushes.Gray;
    }
    return Brushes.Transparent;
}
```

Добавим конвертер в ресурсы:
```xml
<converters:CountToBrushConverter x:Key="countConverter" />
```

Определим стиль для строки внутри `ListView`:
```xml
<ListView.ItemContainerStyle>
    <Style TargetType="ListViewItem">
        <Setter Property="Background" Value="{Binding ProductQuantityInStock, Converter={StaticResource countConverter}}" />
    </Style>
</ListView.ItemContainerStyle>
```

Готово! Проверьте работоспособность.

### Самостоятельно
- проверьте по заданию, не забыли ли мы что-то сделать. При необходимости реализуйте недостающие функции.

### 4. Разработка библиотеки

Разработайте библиотеку классов согласно заданию. Выполните следующее:
- добавьте проект библиотеки классов в решение (учтите, что вам нужно выбрать платформу, соответствующую вашему проекту);
- дайте проекту название, соответствующее заданию;
- добавьте в библиотеку класс, опишите в нем метод с правильной сигнатурой.

В целом, этого хватит, чтобы получить большую часть баллов.

### Дополнительно

Реализуйте алгоритм согласно заданию.

### 5. Разработка тестового проекта

Добавьте в решение проект модульных тестов (NUnit или MsTest). Выполните после этого следующее:
- переименуйте класс (дайте описательное название, закончите его словом `Tests`; например, подойте `CalculationsTests`);
- добавьте ссылку на проект библиотеки классов;

### Дополнительно
Напишите 10 модульных тестов для проверки алгоритма из пункта 4.

### 6. Составление тестовой документации

Заполните тестовые формы (см. шаблон в папке с заданием). Обратите внимание, что вам нужно протестировать только добавление товара. Обратите внимание на раздел документа "Расшифровка тестовых информационных полей".

